create view view_article_comments(comment_id, article_slug, username, content, created_at) as
SELECT c.id              AS comment_id,
       a.slug            AS article_slug,
       cu.username::text AS username,
       c.content,
       c.created_at
FROM comments c
         JOIN users cu ON cu.id = c.user_id
         JOIN articles a ON a.id = c.article_id
ORDER BY c.created_at DESC;

alter table view_article_comments
    owner to postgres;

