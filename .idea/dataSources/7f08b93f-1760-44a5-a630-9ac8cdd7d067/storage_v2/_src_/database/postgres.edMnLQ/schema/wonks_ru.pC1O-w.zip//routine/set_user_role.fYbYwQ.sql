create function set_user_role(_target_user_id integer, _actor_user_id integer, _new_role_name character varying)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _target_current_role_id INTEGER;
    _target_current_role_name TEXT;
    _new_role_id INTEGER;
    _allowed_actor_roles TEXT[] := ARRAY['Administrator'];
    _protected_target_roles TEXT[] := ARRAY['Administrator'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _actor_role_name
    FROM Users u JOIN Roles r ON u.role_id = r.id
    WHERE u.id = _actor_user_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'ACTOR_NOT_FOUND'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN;
    END IF;
    IF NOT (_actor_role_name = ANY(_allowed_actor_roles)) THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to change user roles.'::TEXT; RETURN;
    END IF;

    IF _actor_user_id = _target_user_id THEN
        RETURN QUERY SELECT 'CANNOT_CHANGE_SELF'::TEXT, 'Cannot change your own role using this function.'::TEXT; RETURN;
    END IF;

    SELECT u.role_id, r.name INTO _target_current_role_id, _target_current_role_name
    FROM Users u JOIN Roles r ON u.role_id = r.id
    WHERE u.id = _target_user_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'TARGET_NOT_FOUND'::TEXT, 'Target user not found.'::TEXT; RETURN;
    END IF;

    IF (_target_current_role_name = ANY(_protected_target_roles)) THEN
        RETURN QUERY SELECT 'TARGET_ROLE_PROTECTED'::TEXT, format('Cannot change the role of a user with the protected role: %s.', _target_current_role_name); RETURN;
    END IF;

    SELECT id INTO _new_role_id FROM Roles WHERE name = _new_role_name;
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'NEW_ROLE_NOT_FOUND'::TEXT, format('Role "%s" not found.', _new_role_name); RETURN;
    END IF;

    IF _target_current_role_id = _new_role_id THEN
        RETURN QUERY SELECT 'NO_CHANGES'::TEXT, format('User already has the role "%s".', _new_role_name); RETURN;
    END IF;

    UPDATE Users
    SET role_id = _new_role_id
    WHERE id = _target_user_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('User %s role successfully changed to "%s".', _target_user_id, _new_role_name);
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update user role, user might have been deleted concurrently.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error setting role for user % by user %: %', _target_user_id, _actor_user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while setting user role: ' || SQLERRM::TEXT;
END;
$$;

alter function set_user_role(integer, integer, varchar) owner to postgres;

grant execute on function set_user_role(integer, integer, varchar) to "Админ";

