create function import_schema_from_jsonb(_data jsonb, _schema_name text DEFAULT 'wonks_ru'::text, _mode text DEFAULT 'TRUNCATE'::text)
    returns TABLE(status_code text, message text)
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
DECLARE
    _import_order TEXT[] := ARRAY[
        'roles', 'categories', 'tags', 'users',
        'articles',
        'article_tags', 'comments', 'favourites', 'ratings',
        'subscriptions', 'notifications', 'reports'
        ];
    _table_name TEXT;
    _json_array JSONB;
    _query TEXT;
    _pk_column TEXT := 'id';
    _cols TEXT;
    _val_update TEXT;
    _rec RECORD;
    i INTEGER;
BEGIN
    RAISE NOTICE '[JSONB Import] Starting for schema %. Mode: %. THIS CAN BE DESTRUCTIVE!', _schema_name, _mode;

    IF upper(_mode) NOT IN ('TRUNCATE', 'UPSERT') THEN
        RETURN QUERY SELECT 'INVALID_MODE'::TEXT, 'Invalid import mode specified. Use TRUNCATE or UPSERT.'::TEXT;
        RETURN;
    END IF;

    IF upper(_mode) = 'TRUNCATE' THEN
        RAISE NOTICE '[JSONB Import] TRUNCATE MODE: Deleting data from tables in reverse order...';
        FOR i IN REVERSE array_upper(_import_order, 1) .. array_lower(_import_order, 1) LOOP
                _table_name := _import_order[i];
                BEGIN
                    _query := format('TRUNCATE TABLE %I.%I RESTART IDENTITY CASCADE;', _schema_name, _table_name);
                    RAISE NOTICE '[JSONB Import] Executing: %', _query;
                    EXECUTE _query;
                EXCEPTION
                    WHEN undefined_table THEN
                        RAISE WARNING '[JSONB Import] Skip truncate: Table %.% not found.', _schema_name, _table_name;
                    WHEN OTHERS THEN
                        RAISE WARNING '[JSONB Import] TRUNCATE ERROR for %.%: %', _schema_name, _table_name, SQLERRM;
                        RETURN QUERY SELECT 'ERROR'::TEXT, 'Truncate error for table ' || quote_ident(_table_name) || ': ' || SQLERRM::TEXT;
                        RETURN;
                END;
            END LOOP;
        RAISE NOTICE '[JSONB Import] TRUNCATE MODE: Data deletion complete.';
    END IF;

    FOREACH _table_name IN ARRAY _import_order LOOP
            IF _data ? _table_name THEN
                _json_array := _data -> _table_name;

                IF jsonb_typeof(_json_array) <> 'array' OR jsonb_array_length(_json_array) = 0 THEN
                    RAISE NOTICE '[JSONB Import] Skip: No data or not an array for table %.%', _schema_name, _table_name;
                    CONTINUE;
                END IF;
                IF jsonb_typeof(_json_array -> 0) <> 'object' THEN
                    RAISE WARNING '[JSONB Import] Skip: First element is not an object for table %.%', _schema_name, _table_name;
                    CONTINUE;
                END IF;

                RAISE NOTICE '[JSONB Import] Importing data for table: %.%', _schema_name, _table_name;

                SELECT string_agg(quote_ident(key), ', ')
                INTO _cols
                FROM jsonb_object_keys(_json_array -> 0) AS keys(key);

                IF _cols IS NULL THEN
                    RAISE WARNING '[JSONB Import] Skip: Could not determine columns from JSON for table %.%', _schema_name, _table_name;
                    CONTINUE;
                END IF;

                _query := format(
                        'INSERT INTO %I.%I (%s) SELECT %s FROM jsonb_populate_recordset(NULL::%I.%I, %L::jsonb)',
                        _schema_name, _table_name, _cols, _cols, _schema_name, _table_name, _json_array
                          );

                IF upper(_mode) = 'UPSERT' THEN
                    SELECT string_agg(format('%I = EXCLUDED.%I', key, key), ', ')
                    INTO _val_update
                    FROM jsonb_object_keys(_json_array -> 0) AS keys(key)
                    WHERE key <> _pk_column;

                    IF _val_update IS NOT NULL AND _val_update <> '' THEN
                        _query := _query || format(' ON CONFLICT (%I) DO UPDATE SET %s', _pk_column, _val_update);
                    ELSE
                        _query := _query || format(' ON CONFLICT (%I) DO NOTHING', _pk_column);
                    END IF;
                ELSE
                    _query := _query || format(' ON CONFLICT (%I) DO NOTHING', _pk_column);
                END IF;

                BEGIN
                    EXECUTE _query;
                    RAISE NOTICE '[JSONB Import] Finished INSERT/UPSERT for %.', _table_name;
                EXCEPTION
                    WHEN OTHERS THEN
                        RAISE WARNING '[JSONB Import] ERROR during INSERT/UPSERT for %.%: %', _schema_name, _table_name, SQLERRM;
                        RETURN QUERY SELECT 'ERROR'::TEXT, 'Error during import for table ' || quote_ident(_table_name) || ': ' || SQLERRM::TEXT;
                        RETURN;
                END;

            ELSE
                RAISE WARNING '[JSONB Import] No data found in JSON for table: %.%', _schema_name, _table_name;
            END IF;
        END LOOP;

    RAISE NOTICE '[JSONB Import] Resetting sequences...';
    FOR _rec IN
        SELECT
            seq.sequence_name,
            ic.table_name,
            ic.column_name
        FROM information_schema.sequences seq
                 JOIN information_schema.columns ic ON seq.sequence_schema = ic.table_schema
            AND seq.sequence_name = pg_get_serial_sequence(quote_ident(ic.table_schema) || '.' || quote_ident(ic.table_name), ic.column_name)
        WHERE seq.sequence_schema = _schema_name
          AND ic.table_schema = _schema_name
          AND ic.table_name = ANY(_import_order)
        LOOP
            BEGIN
                _query := format(
                        'SELECT setval(%L, COALESCE(max(%I), 1)) FROM %I.%I',
                        _schema_name || '.' || _rec.sequence_name,
                        _rec.column_name,
                        _schema_name,
                        _rec.table_name
                          );
                EXECUTE _query;
                RAISE NOTICE '[JSONB Import] Reset sequence for %.% column %', _schema_name, _rec.table_name, _rec.column_name;
            EXCEPTION
                WHEN undefined_table THEN
                    RAISE WARNING '[JSONB Import] Skip sequence reset: Table %.% not found.', _schema_name, _rec.table_name;
                WHEN query_canceled THEN
                    RAISE NOTICE '[JSONB Import] Sequence reset skipped for empty table %.%', _schema_name, _rec.table_name;
                    _query := format('SELECT setval(%L, 1, false)', _schema_name || '.' || _rec.sequence_name);
                    EXECUTE _query;
                WHEN OTHERS THEN
                    RAISE WARNING '[JSONB Import] Error resetting sequence for %.% column %: %', _schema_name, _rec.table_name, _rec.column_name, SQLERRM;
            END;
        END LOOP;
    RAISE NOTICE '[JSONB Import] Sequence reset complete.';

    RETURN QUERY SELECT 'OK'::TEXT, 'JSON data imported successfully.'::TEXT;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[JSONB Import] CRITICAL ERROR during import process: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'A critical error occurred during import: ' || SQLERRM::TEXT;
END;
$$;

alter function import_schema_from_jsonb(jsonb, text, text) owner to postgres;

grant execute on function import_schema_from_jsonb(jsonb, text, text) to "Админ";

