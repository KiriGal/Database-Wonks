create function import_schema_with_copy(_schema_name text DEFAULT 'wonks_ru'::text, _mode text DEFAULT 'TRUNCATE'::text)
    returns TABLE(status_code text, message text)
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
DECLARE
    _import_order TEXT[] := ARRAY[
        'roles', 'categories', 'tags', 'users',
        'articles',
        'article_tags',
        'comments',
        'favourites',
        'ratings',
        'subscriptions',
        'notifications',
        'reports'
        ];
    _table_name TEXT;
    _file_path TEXT;
    _query TEXT;
    _rec RECORD;
    _base_import_dir TEXT := '/var/lib/postgresql/io';
BEGIN
    RAISE WARNING 'Starting schema import using COPY FROM directory %. Mode: %. THIS CAN BE DESTRUCTIVE!', _base_import_dir, _mode;

    IF upper(_mode) <> 'TRUNCATE' THEN
        RETURN QUERY SELECT 'INVALID_MODE'::TEXT, 'COPY import only supports TRUNCATE mode.'::TEXT;
        RETURN;
    END IF;

    RAISE WARNING 'TRUNCATE MODE: Deleting all data from tables in schema % in reverse dependency order.', _schema_name;
    FOREACH _table_name IN ARRAY reverse(_import_order) LOOP
            BEGIN
                _query := format('TRUNCATE TABLE %I.%I RESTART IDENTITY CASCADE;', _schema_name, _table_name);
                RAISE NOTICE 'Executing: %', _query;
                EXECUTE _query;
            EXCEPTION
                WHEN undefined_table THEN
                    RAISE WARNING 'Table %.% not found for truncation, skipping.', _schema_name, _table_name;
                WHEN OTHERS THEN
                    RAISE WARNING 'Error truncating table %.%: %', _schema_name, _table_name, SQLERRM;
                    RETURN QUERY SELECT 'ERROR'::TEXT, 'Error during TRUNCATE: ' || SQLERRM::TEXT;
                    RETURN;
            END;
        END LOOP;
    RAISE WARNING 'TRUNCATE MODE: Data deletion complete.';

    FOREACH _table_name IN ARRAY _import_order LOOP
            _file_path := _base_import_dir || '/' || _table_name || '.csv';

            _query := format(
                    'COPY %I.%I FROM %L WITH (FORMAT CSV, HEADER)',
                    _schema_name,
                    _table_name,
                    _file_path
                      );

            RAISE NOTICE 'Executing: %', _query;
            BEGIN
                EXECUTE _query;
                RAISE NOTICE 'Imported data for table %.% from %', _schema_name, _table_name, _file_path;
            EXCEPTION
                WHEN undefined_file THEN
                    RAISE WARNING 'File % for table %.% not found or permissions error, skipping import for this table.', _file_path, _schema_name, _table_name;
                    CONTINUE;
                WHEN OTHERS THEN
                    RAISE WARNING 'Error importing data for table %.% from file %: %', _schema_name, _table_name, _file_path, SQLERRM;
                    RETURN QUERY SELECT 'ERROR'::TEXT, format('Error importing table %s: %s', _table_name, SQLERRM::TEXT);
                    RETURN;
            END;
        END LOOP;

    RAISE NOTICE 'Resetting sequences...';
    FOR _rec IN
        SELECT
            seq.sequence_name,
            ic.table_name,
            ic.column_name
        FROM information_schema.sequences seq
                 JOIN information_schema.columns ic
                      ON seq.sequence_schema = ic.table_schema
                          AND seq.sequence_name = pg_get_serial_sequence(quote_ident(ic.table_schema) || '.' || quote_ident(ic.table_name), ic.column_name)
        WHERE seq.sequence_schema = _schema_name
          AND ic.table_schema = _schema_name
          AND ic.table_name = ANY(_import_order)
        LOOP
            _query := format(
                    'SELECT setval(%L, COALESCE(max(%I), 1)) FROM %I.%I',
                    _schema_name || '.' || _rec.sequence_name,
                    _rec.column_name,
                    _schema_name,
                    _rec.table_name
                      );
            RAISE NOTICE 'Resetting sequence for %.% column %', _schema_name, _rec.table_name, _rec.column_name;
            EXECUTE _query;
        END LOOP;
    RAISE NOTICE 'Sequence reset complete.';


    RETURN QUERY SELECT 'OK'::TEXT, 'Schema import using COPY completed. Check logs for potential errors.'::TEXT;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Critical error during COPY import process: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'A critical error occurred during the import process: ' || SQLERRM::TEXT;
END;
$$;

alter function import_schema_with_copy(text, text) owner to postgres;

