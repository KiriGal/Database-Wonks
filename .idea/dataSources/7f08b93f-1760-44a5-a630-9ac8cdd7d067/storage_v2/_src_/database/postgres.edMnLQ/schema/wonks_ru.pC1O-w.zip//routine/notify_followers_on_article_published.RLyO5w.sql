create function notify_followers_on_article_published() returns trigger
    security definer
    language plpgsql
as
$$
DECLARE
    follower RECORD;
    article_author_id INTEGER;
BEGIN
    IF OLD.status IS DISTINCT FROM 'published' AND NEW.status = 'published' THEN

        article_author_id := NEW.user_id;

        FOR follower IN
            SELECT s.follower_id
            FROM wonks_ru.Subscriptions s
            WHERE s.followed_id = article_author_id
              AND s.notices = true
            LOOP
                INSERT INTO wonks_ru.Notifications(user_id, text)
                VALUES (follower.follower_id,
                        CONCAT(
                                'Пользователь, на которого вы подписаны (ID: ', article_author_id, '), опубликовал статью "',
                                NEW.title, '".'
                        ));
            END LOOP;
    END IF;

    RETURN NEW;
END;
$$;

alter function notify_followers_on_article_published() owner to postgres;

