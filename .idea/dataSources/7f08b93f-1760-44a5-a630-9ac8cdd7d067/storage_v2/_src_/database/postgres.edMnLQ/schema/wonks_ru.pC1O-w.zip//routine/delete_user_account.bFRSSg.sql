create function delete_user_account(_target_user_id integer, _actor_user_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _target_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator'];
    _protected_roles TEXT[] := ARRAY['Administrator'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _actor_role_name
    FROM Users u JOIN Roles r ON u.role_id = r.id
    WHERE u.id = _actor_user_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'ACTOR_NOT_FOUND'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN; END IF;
    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to delete user accounts.'::TEXT; RETURN; END IF;

    IF _actor_user_id = _target_user_id THEN RETURN QUERY SELECT 'CANNOT_DELETE_SELF'::TEXT, 'Cannot delete your own account using this function.'::TEXT; RETURN; END IF;

    SELECT r.name INTO _target_role_name
    FROM Users u JOIN Roles r ON u.role_id = r.id
    WHERE u.id = _target_user_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'TARGET_NOT_FOUND'::TEXT, 'Target user not found.'::TEXT; RETURN; END IF;

    IF (_target_role_name = ANY(_protected_roles)) THEN RETURN QUERY SELECT 'CANNOT_DELETE_ADMIN'::TEXT, format('Cannot delete a user with the protected role: %s.', _target_role_name); RETURN; END IF;

    DELETE FROM Users WHERE id = _target_user_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('User %s account and associated data deleted successfully.', _target_user_id);
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to delete user, possibly already deleted.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting user % by actor %: %', _target_user_id, _actor_user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during user deletion: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_user_account(integer, integer) owner to postgres;

grant execute on function delete_user_account(integer, integer) to "Админ";

