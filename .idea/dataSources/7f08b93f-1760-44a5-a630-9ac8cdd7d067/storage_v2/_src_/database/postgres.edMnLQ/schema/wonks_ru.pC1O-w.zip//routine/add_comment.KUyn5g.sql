create function add_comment(_user_id integer, _article_id integer, _content text)
    returns TABLE(new_comment_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _trimmed_content TEXT;
    _inserted_id INTEGER := NULL;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM Articles WHERE id = _article_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    _trimmed_content := TRIM(_content);
    IF _trimmed_content IS NULL OR _trimmed_content = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'EMPTY_CONTENT'::TEXT, 'Comment content cannot be empty.'::TEXT;
        RETURN;
    END IF;

    INSERT INTO Comments (user_id, article_id, content)
    VALUES (_user_id, _article_id, _trimmed_content)
    RETURNING id INTO _inserted_id;

    IF _inserted_id IS NOT NULL THEN
        RETURN QUERY SELECT _inserted_id, 'OK'::TEXT, 'Comment added successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to insert comment record.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error adding comment: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred while adding the comment: ' || SQLERRM::TEXT;
END;
$$;

alter function add_comment(integer, integer, text) owner to postgres;

grant execute on function add_comment(integer, integer, text) to "Админ";

grant execute on function add_comment(integer, integer, text) to "Модератор";

grant execute on function add_comment(integer, integer, text) to "Пользователь";

