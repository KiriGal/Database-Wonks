create function import_schema_from_json_file(_file_name text, _schema_name text DEFAULT 'wonks_ru'::text, _mode text DEFAULT 'TRUNCATE'::text)
    returns TABLE(status_code text, message text)
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
DECLARE
    _base_import_dir TEXT := '/var/lib/postgresql/io';
    _full_path TEXT;
    _cat_argument TEXT;
    _shell_command TEXT;
    _query TEXT;
    _imported_data JSONB;
    _import_result RECORD;
BEGIN
    IF _file_name IS NULL OR _file_name = '' OR _file_name ~ '[/\\]' OR _file_name = '.' OR _file_name = '..' THEN
        RETURN QUERY SELECT 'INVALID_FILENAME'::TEXT, 'Invalid or potentially unsafe filename provided.'::TEXT;
        RETURN;
    END IF;

    IF upper(_mode) NOT IN ('TRUNCATE', 'UPSERT') THEN
        RETURN QUERY SELECT 'INVALID_MODE'::TEXT, 'Invalid import mode specified. Use TRUNCATE or UPSERT.'::TEXT;
        RETURN;
    END IF;

    _full_path := _base_import_dir || '/' || _file_name;
    RAISE NOTICE '[File Import] Starting schema import using COPY FROM PROGRAM for file: %', _full_path;

    CREATE TEMP TABLE __json_import_temp (data JSONB) ON COMMIT DROP;

    _cat_argument := quote_literal(_full_path);

    _shell_command := 'sh -c ''cat ' || _cat_argument || '''';

    _query := format('COPY __json_import_temp FROM PROGRAM %L', _shell_command);

    RAISE NOTICE '[File Import] Executing COPY FROM PROGRAM command: %', _query;
    BEGIN
        EXECUTE _query;
    EXCEPTION
        WHEN undefined_file OR program_limit_exceeded THEN
            RAISE WARNING '[File Import] File % not found or permissions error accessing it.', _full_path;
            RETURN QUERY SELECT 'FILE_NOT_FOUND'::TEXT AS status_code, 'Import file not found or cannot be accessed by the postgres user.'::TEXT AS message;
            RETURN;
        WHEN OTHERS THEN
            RAISE WARNING '[File Import] Error during COPY FROM PROGRAM for file %: %', _full_path, SQLERRM;
            RETURN QUERY SELECT 'COPY_ERROR'::TEXT AS status_code, ('Error reading import file: ' || SQLERRM::TEXT)::TEXT AS message;
            RETURN;
    END;

    SELECT data INTO _imported_data FROM __json_import_temp LIMIT 1;

    IF _imported_data IS NULL THEN
        RAISE WARNING '[File Import] Could not read JSON data from temporary table after COPY FROM %.', _full_path;
        RETURN QUERY SELECT 'JSON_READ_ERROR'::TEXT AS status_code, 'Failed to read JSON data from the import file (possibly empty or invalid JSON format).'::TEXT AS message;
        RETURN;
    END IF;

    RAISE NOTICE '[File Import] Calling internal JSONB import function.';
    SELECT r.status_code, r.message INTO _import_result
    FROM wonks_ru.import_schema_from_jsonb(_imported_data, _schema_name, _mode) r;

    RETURN QUERY SELECT
                     _import_result.status_code AS status_code,
                     _import_result.message AS message;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[File Import] CRITICAL error during file import process: %', SQLERRM;
        RETURN QUERY SELECT
                         'ERROR'::TEXT AS status_code,
                         ('A critical error occurred during the import process: ' || SQLERRM::TEXT)::TEXT AS message;
END;
$$;

alter function import_schema_from_json_file(text, text, text) owner to postgres;

grant execute on function import_schema_from_json_file(text, text, text) to "Админ";

