create function export_schema_with_copy(_schema_name text DEFAULT 'wonks_ru'::text)
    returns TABLE(status_code text, message text)
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
DECLARE
    _table_record RECORD;
    _file_path TEXT;
    _query TEXT;
    _base_export_dir TEXT := '/var/lib/postgresql/io';
BEGIN
    RAISE NOTICE 'Starting schema export using COPY TO directory: %', _base_export_dir;

    FOR _table_record IN
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = _schema_name AND table_type = 'BASE TABLE'
        ORDER BY table_name
        LOOP
            _file_path := _base_export_dir || '/' || _table_record.table_name || '.csv';

            _query := format(
                    'COPY %I.%I TO %L WITH (FORMAT CSV, HEADER)',
                    _schema_name,
                    _table_record.table_name,
                    _file_path
                      );

            RAISE NOTICE 'Executing: %', _query;
            BEGIN
                EXECUTE _query;
                RAISE NOTICE 'Exported table %.% to %', _schema_name, _table_record.table_name, _file_path;
            EXCEPTION
                WHEN OTHERS THEN
                    RAISE WARNING 'Error exporting table %.% to file %: %', _schema_name, _table_record.table_name, _file_path, SQLERRM;
                    CONTINUE;
            END;
        END LOOP;

    RETURN QUERY SELECT 'OK'::TEXT, 'Schema export using COPY completed. Check logs for potential errors.'::TEXT;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Critical error during COPY export process: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'A critical error occurred during the export process: ' || SQLERRM::TEXT;
END;
$$;

alter function export_schema_with_copy(text) owner to postgres;

