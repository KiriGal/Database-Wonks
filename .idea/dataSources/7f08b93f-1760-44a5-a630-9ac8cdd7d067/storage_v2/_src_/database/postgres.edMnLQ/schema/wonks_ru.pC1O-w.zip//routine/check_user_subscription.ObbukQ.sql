create function check_user_subscription(_follower_id integer, _followed_id integer) returns boolean
    stable
    security definer
    language sql
as
$$
SELECT EXISTS (SELECT 1 FROM Subscriptions WHERE follower_id = _follower_id AND followed_id = _followed_id);
$$;

alter function check_user_subscription(integer, integer) owner to postgres;

grant execute on function check_user_subscription(integer, integer) to "Админ";

grant execute on function check_user_subscription(integer, integer) to "Модератор";

grant execute on function check_user_subscription(integer, integer) to "Пользователь";

