create function get_user_favourite_articles_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_user_id integer DEFAULT NULL::integer, filter_username text DEFAULT NULL::text, filter_article_slug text DEFAULT NULL::text, filter_article_title text DEFAULT NULL::text)
    returns TABLE(favourite_id integer, user_id integer, username text, slug text, title text, image text, short_description text)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN
    query := 'SELECT favourite_id, user_id, username, slug, title, image, short_description
              FROM view_user_favourite_articles';

    IF filter_user_id IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('user_id = %L', filter_user_id));
    END IF;
    IF filter_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('username = %L', filter_username));
    END IF;
    IF filter_article_slug IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('slug = %L', filter_article_slug));
    END IF;
    IF filter_article_title IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('title ILIKE %L', '%' || filter_article_title || '%'));
    END IF;

    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;

    query := query || format(' ORDER BY favourite_id DESC LIMIT %L OFFSET %L', _limit, _offset);
    RAISE NOTICE 'Executing query: %', query;
    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_user_favourite_articles_paginated_filtered(integer, integer, integer, text, text, text) owner to postgres;

grant execute on function get_user_favourite_articles_paginated_filtered(integer, integer, integer, text, text, text) to "Админ";

grant execute on function get_user_favourite_articles_paginated_filtered(integer, integer, integer, text, text, text) to "Модератор";

grant execute on function get_user_favourite_articles_paginated_filtered(integer, integer, integer, text, text, text) to "Пользователь";

