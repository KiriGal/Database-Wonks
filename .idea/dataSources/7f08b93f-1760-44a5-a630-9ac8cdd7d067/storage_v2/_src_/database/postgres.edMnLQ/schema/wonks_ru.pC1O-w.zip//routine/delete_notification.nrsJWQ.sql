create function delete_notification(_notification_id integer, _user_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _notification_recipient_id INTEGER;
    _row_count INTEGER;
BEGIN
    SELECT user_id INTO _notification_recipient_id
    FROM Notifications
    WHERE id = _notification_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Notification not found.'::TEXT;
        RETURN;
    END IF;

    IF _notification_recipient_id <> _user_id THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You do not have permission to delete this notification.'::TEXT;
        RETURN;
    END IF;

    DELETE FROM Notifications
    WHERE id = _notification_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Notification deleted successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to delete notification, possibly already deleted.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting notification: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while deleting the notification: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_notification(integer, integer) owner to postgres;

grant execute on function delete_notification(integer, integer) to "Админ";

grant execute on function delete_notification(integer, integer) to "Модератор";

grant execute on function delete_notification(integer, integer) to "Пользователь";

