create function get_unread_notification_count(_user_id integer) returns integer
    stable
    security definer
    language sql
as
$$
SELECT COUNT(*)::INTEGER FROM Notifications
WHERE user_id = _user_id AND is_read = false;
$$;

alter function get_unread_notification_count(integer) owner to postgres;

grant execute on function get_unread_notification_count(integer) to "Админ";

grant execute on function get_unread_notification_count(integer) to "Модератор";

grant execute on function get_unread_notification_count(integer) to "Пользователь";

