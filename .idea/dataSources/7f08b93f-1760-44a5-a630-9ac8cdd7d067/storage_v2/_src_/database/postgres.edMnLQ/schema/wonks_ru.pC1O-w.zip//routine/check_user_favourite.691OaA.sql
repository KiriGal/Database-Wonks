create function check_user_favourite(_user_id integer, _article_id integer) returns boolean
    stable
    security definer
    language sql
as
$$
SELECT EXISTS (SELECT 1 FROM Favourites WHERE user_id = _user_id AND article_id = _article_id);
$$;

alter function check_user_favourite(integer, integer) owner to postgres;

grant execute on function check_user_favourite(integer, integer) to "Админ";

grant execute on function check_user_favourite(integer, integer) to "Модератор";

grant execute on function check_user_favourite(integer, integer) to "Пользователь";

