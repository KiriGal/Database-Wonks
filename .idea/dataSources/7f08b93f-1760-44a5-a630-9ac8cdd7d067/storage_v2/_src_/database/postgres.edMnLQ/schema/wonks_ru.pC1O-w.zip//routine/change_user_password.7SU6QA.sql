create function change_user_password(_user_id integer, _old_plain_password text, _new_plain_password text)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _user_record RECORD;
    _new_hashed_password TEXT;
BEGIN
    SELECT id, password_hash, status INTO _user_record
    FROM Users WHERE id = _user_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT; RETURN;
    END IF;

    IF _user_record.password_hash <> crypt(_old_plain_password, _user_record.password_hash) THEN
        RETURN QUERY SELECT 'INCORRECT_OLD_PASSWORD'::TEXT, 'Incorrect current password.'::TEXT; RETURN;
    END IF;

    IF _new_plain_password IS NULL OR TRIM(_new_plain_password) = '' THEN
        RETURN QUERY SELECT 'INVALID_NEW_PASSWORD'::TEXT, 'New password cannot be empty.'::TEXT; RETURN;
    END IF;

    _new_hashed_password := crypt(_new_plain_password, gen_salt('bf'));

    UPDATE Users
    SET password_hash = _new_hashed_password
    WHERE id = _user_id;

    RETURN QUERY SELECT 'OK'::TEXT, 'Password changed successfully.'::TEXT;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error changing password for user %: %', _user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while changing password: ' || SQLERRM::TEXT;
END;
$$;

alter function change_user_password(integer, text, text) owner to postgres;

grant execute on function change_user_password(integer, text, text) to "Админ";

grant execute on function change_user_password(integer, text, text) to "Модератор";

grant execute on function change_user_password(integer, text, text) to "Пользователь";

