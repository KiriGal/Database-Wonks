create function create_tag(_actor_user_id integer, _tag_name character varying)
    returns TABLE(new_tag_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Moderator'];
    _trimmed_name VARCHAR(255);
    _inserted_id INTEGER := NULL;
BEGIN
    SELECT r.name INTO _actor_role_name FROM Users u JOIN Roles r ON u.role_id = r.id WHERE u.id = _actor_user_id;
    IF NOT FOUND THEN RETURN QUERY SELECT NULL::INTEGER, 'FORBIDDEN'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN; END IF;
    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN RETURN QUERY SELECT NULL::INTEGER, 'FORBIDDEN'::TEXT, 'User does not have permission to create tags.'::TEXT; RETURN; END IF;

    _trimmed_name := TRIM(_tag_name);
    IF _trimmed_name IS NULL OR _trimmed_name = '' THEN RETURN QUERY SELECT NULL::INTEGER, 'INVALID_INPUT'::TEXT, 'Tag name cannot be empty.'::TEXT; RETURN; END IF;

    IF EXISTS (SELECT 1 FROM Tags WHERE lower(name) = lower(_trimmed_name)) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'NAME_EXISTS'::TEXT, 'Tag name already exists.'::TEXT; RETURN;
    END IF;

    INSERT INTO Tags (name)
    VALUES (_trimmed_name)
    RETURNING id INTO _inserted_id;

    IF _inserted_id IS NOT NULL THEN
        RETURN QUERY SELECT _inserted_id, 'OK'::TEXT, 'Tag created successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to insert tag record.'::TEXT;
    END IF;

EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::INTEGER, 'NAME_EXISTS'::TEXT, 'Tag name already exists (concurrent creation).';
    WHEN OTHERS THEN
        RAISE WARNING 'Error creating tag by user %: %', _actor_user_id, SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function create_tag(integer, varchar) owner to postgres;

grant execute on function create_tag(integer, varchar) to "Админ";

grant execute on function create_tag(integer, varchar) to "Модератор";

