create function get_user_feed(_user_id integer, _limit integer DEFAULT 10, _offset integer DEFAULT 0)
    returns TABLE(id integer, slug text, title text, short_description text, image text, created_at timestamp with time zone, category_name text, author_username text, rating numeric, comment_count bigint)
    stable
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            a.id,
            a.slug::TEXT,
            a.title::TEXT,
            a.short_description::TEXT,
            a.image::TEXT,
            a.created_at,
            cat.name::TEXT as category_name,
            u.username::TEXT as author_username,
            (SELECT COALESCE(ROUND(AVG(r.value)::numeric, 2), 0) FROM Ratings r WHERE r.article_id = a.id) as rating,
            (SELECT COUNT(*) FROM Comments cm WHERE cm.article_id = a.id) as comment_count
        FROM Articles a
                 JOIN Users u ON a.user_id = u.id
                 JOIN Categories cat ON a.category_id = cat.id
                 JOIN Subscriptions s ON a.user_id = s.followed_id
        WHERE s.follower_id = _user_id AND a.status = 'published'
        ORDER BY a.created_at DESC
        LIMIT _limit
            OFFSET _offset;
END;
$$;

alter function get_user_feed(integer, integer, integer) owner to postgres;

grant execute on function get_user_feed(integer, integer, integer) to "Админ";

grant execute on function get_user_feed(integer, integer, integer) to "Модератор";

grant execute on function get_user_feed(integer, integer, integer) to "Пользователь";

