create function update_article_timestamp() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

alter function update_article_timestamp() owner to postgres;

