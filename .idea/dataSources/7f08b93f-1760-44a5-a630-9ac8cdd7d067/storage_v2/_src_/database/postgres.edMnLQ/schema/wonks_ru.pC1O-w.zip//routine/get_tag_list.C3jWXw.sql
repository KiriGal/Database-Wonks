create function get_tag_list()
    returns TABLE(id integer, name text)
    stable
    security definer
    language sql
as
$$
SELECT t.id, t.name::TEXT FROM Tags t ORDER BY name;
$$;

alter function get_tag_list() owner to postgres;

grant execute on function get_tag_list() to "Админ";

grant execute on function get_tag_list() to "Модератор";

grant execute on function get_tag_list() to "Пользователь";

grant execute on function get_tag_list() to "Гость";

