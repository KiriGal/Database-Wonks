create function update_article(_article_id integer, _user_id integer, _new_title character varying DEFAULT NULL::character varying, _new_slug text DEFAULT NULL::text, _new_content text DEFAULT NULL::text, _new_short_description text DEFAULT NULL::text, _new_image character varying DEFAULT NULL::character varying, _new_category_id integer DEFAULT NULL::integer, _new_status article_status DEFAULT NULL::article_status, _new_tags text[] DEFAULT NULL::text[])
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _original_author_id INTEGER;
    _update_clauses TEXT[] := '{}';
    _query TEXT;
    _tag_id INTEGER;
    _tag_name TEXT;
    _changes_made BOOLEAN := false;
BEGIN
    SELECT user_id INTO _original_author_id FROM Articles WHERE id = _article_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    IF _original_author_id <> _user_id THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You do not have permission to edit this article.'::TEXT;
        RETURN;
    END IF;

    IF _new_title IS NOT NULL THEN
        IF EXISTS (SELECT 1 FROM Articles WHERE lower(title) = lower(_new_title) AND id <> _article_id) THEN
            RETURN QUERY SELECT 'TITLE_EXISTS'::TEXT, 'New title is already in use.'::TEXT; RETURN;
        END IF;
        _update_clauses := array_append(_update_clauses, format('title = %L', _new_title));
        _changes_made := true;
    END IF;
    IF _new_slug IS NOT NULL THEN
        IF EXISTS (SELECT 1 FROM Articles WHERE slug = _new_slug AND id <> _article_id) THEN
            RETURN QUERY SELECT 'SLUG_EXISTS'::TEXT, 'New slug is already in use.'::TEXT; RETURN;
        END IF;
        _update_clauses := array_append(_update_clauses, format('slug = %L', _new_slug));
        _changes_made := true;
    END IF;
    IF _new_content IS NOT NULL THEN
        _update_clauses := array_append(_update_clauses, format('content = %L', _new_content));
        _changes_made := true;
    END IF;
    IF _new_short_description IS NOT NULL THEN
        _update_clauses := array_append(_update_clauses, format('short_description = %L', _new_short_description));
        _changes_made := true;
    END IF;
    IF _new_image IS NOT NULL THEN
        _update_clauses := array_append(_update_clauses, format('image = %L', _new_image));
        _changes_made := true;
    END IF;
    IF _new_category_id IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM Categories WHERE id = _new_category_id) THEN
            RETURN QUERY SELECT 'CATEGORY_NOT_FOUND'::TEXT, 'Category not found.'::TEXT; RETURN;
        END IF;
        _update_clauses := array_append(_update_clauses, format('category_id = %L', _new_category_id));
        _changes_made := true;
    END IF;
    IF _new_status IS NOT NULL THEN
        _update_clauses := array_append(_update_clauses, format('status = %L', _new_status));
        _changes_made := true;
    END IF;

    IF _changes_made THEN
        _update_clauses := array_append(_update_clauses, 'updated_at = NOW()');
    END IF;

    IF _new_tags IS NOT NULL THEN
        _changes_made := true;

        DELETE FROM Article_tags WHERE article_id = _article_id;

        IF array_length(_new_tags, 1) > 0 THEN
            FOREACH _tag_name IN ARRAY _new_tags LOOP
                    _tag_name := TRIM(_tag_name);
                    IF _tag_name <> '' THEN
                        SELECT id INTO _tag_id FROM Tags WHERE lower(name) = lower(_tag_name);
                        IF NOT FOUND THEN
                            INSERT INTO Tags (name) VALUES (_tag_name)
                            ON CONFLICT (name) DO NOTHING RETURNING id INTO _tag_id;
                            IF _tag_id IS NULL THEN SELECT id INTO _tag_id FROM Tags WHERE lower(name) = lower(_tag_name); END IF;
                        END IF;
                        IF _tag_id IS NOT NULL THEN
                            INSERT INTO Article_tags (article_id, tag_id)
                            VALUES (_article_id, _tag_id) ON CONFLICT DO NOTHING;
                        ELSE
                            RAISE WARNING 'Could not find or create tag during update: %', _tag_name;
                        END IF;
                    END IF;
                END LOOP;
        END IF;
    END IF;


    IF NOT _changes_made THEN
        RETURN QUERY SELECT 'NO_CHANGES'::TEXT, 'No changes requested.'::TEXT;
        RETURN;
    END IF;

    IF array_length(_update_clauses, 1) > 0 THEN
        _query := format('UPDATE Articles SET %s WHERE id = %L',
                         array_to_string(_update_clauses, ', '),
                         _article_id);
        RAISE NOTICE 'Executing update query: %', _query;
        EXECUTE _query;
    END IF;


    RETURN QUERY SELECT 'OK'::TEXT, 'Article updated successfully.'::TEXT;

EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Update failed due to unique constraint violation (title or slug).';
    WHEN foreign_key_violation THEN
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Update failed due to foreign key constraint violation (category_id).';
    WHEN invalid_text_representation THEN
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Invalid status value provided.';
    WHEN OTHERS THEN
        RAISE WARNING 'Error updating article: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during article update: ' || SQLERRM::TEXT;
END;
$$;

alter function update_article(integer, integer, varchar, text, text, text, varchar, integer, article_status, text[]) owner to postgres;

grant execute on function update_article(integer, integer, varchar, text, text, text, varchar, integer, article_status, text[]) to "Админ";

grant execute on function update_article(integer, integer, varchar, text, text, text, varchar, integer, article_status, text[]) to "Модератор";

grant execute on function update_article(integer, integer, varchar, text, text, text, varchar, integer, article_status, text[]) to "Пользователь";

