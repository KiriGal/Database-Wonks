create function export_schema_to_json_file(_file_name text, _schema_name text DEFAULT 'wonks_ru'::text)
    returns TABLE(status_code text, message text)
    security definer
    SET search_path = wonks_ru, pg_catalog
    language plpgsql
as
$$
DECLARE
    _base_export_dir TEXT := '/var/lib/postgresql/io';
    _full_path TEXT;
    _program_cmd TEXT;
    _query TEXT;
BEGIN
    IF _file_name IS NULL OR _file_name = '' OR _file_name ~ '[/\\]' OR _file_name = '.' OR _file_name = '..' THEN
        RETURN QUERY SELECT 'INVALID_FILENAME'::TEXT, 'Invalid or potentially unsafe filename provided.'::TEXT;
        RETURN;
    END IF;

    _full_path := _base_export_dir || '/' || _file_name;
    RAISE NOTICE 'Starting schema export using COPY TO PROGRAM for file: %', _full_path;

    _program_cmd := format('sh -c %L', 'cat > ' || _full_path);

    _query := format(
            'COPY (SELECT export_schema_to_jsonb(%L)) TO PROGRAM %L',
            _schema_name,
            _program_cmd
              );

    RAISE NOTICE 'Executing COPY TO PROGRAM: %', _query;
    BEGIN
        EXECUTE _query;
        RAISE NOTICE 'Schema export to file % completed.', _full_path;
        RETURN QUERY SELECT 'OK'::TEXT, format('Schema successfully exported to file %s.', _file_name);
    EXCEPTION
        WHEN OTHERS THEN
            RAISE WARNING 'Error during COPY TO PROGRAM export to file %: %', _full_path, SQLERRM;
            RETURN QUERY SELECT 'ERROR'::TEXT, 'Error during export: ' || SQLERRM::TEXT;
    END;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Critical error during file export setup: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'A critical setup error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function export_schema_to_json_file(text, text) owner to postgres;

grant execute on function export_schema_to_json_file(text, text) to "Админ";

