create function create_article(_user_id integer, _title character varying, _slug text, _content text, _short_description text, _category_id integer, _status article_status, _image character varying DEFAULT NULL::character varying, _tags text[] DEFAULT NULL::text[])
    returns TABLE(new_article_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _inserted_article_id INTEGER := NULL;
    _tag_id INTEGER;
    _tag_name TEXT;
    _final_image VARCHAR(255);
BEGIN
    IF _user_id IS NULL OR _title IS NULL OR TRIM(_title) = '' OR _slug IS NULL OR TRIM(_slug) = '' OR
       _content IS NULL OR TRIM(_content) = '' OR _short_description IS NULL OR TRIM(_short_description) = '' OR
       _category_id IS NULL OR _status IS NULL
    THEN
        RETURN QUERY SELECT NULL::INTEGER, 'INVALID_INPUT'::TEXT, 'Обязательные поля (пользователь, заголовок, slug, содержимое, краткое описание, категория, статус) не могут быть пустыми.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'USER_NOT_FOUND'::TEXT, 'Пользователь-автор не найден.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM Categories WHERE id = _category_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'CATEGORY_NOT_FOUND'::TEXT, 'Категория не найдена.'::TEXT;
        RETURN;
    END IF;

    IF EXISTS (SELECT 1 FROM Articles WHERE lower(title) = lower(_title)) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'TITLE_EXISTS'::TEXT, 'Статья с таким заголовком уже существует.'::TEXT;
        RETURN;
    END IF;

    IF EXISTS (SELECT 1 FROM Articles WHERE slug = _slug) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'SLUG_EXISTS'::TEXT, 'Статья с таким slug уже существует.'::TEXT;
        RETURN;
    END IF;

    _final_image := COALESCE(_image, (SELECT column_default FROM information_schema.columns
                                      WHERE table_schema = 'wonks_ru' AND table_name = 'articles' AND column_name = 'image'
                                      LIMIT 1)::VARCHAR);
    _final_image := COALESCE(_final_image, 'noimage.png');


    INSERT INTO Articles
    (user_id, title, slug, content, short_description, category_id, status, image, created_at, updated_at)
    VALUES
        (_user_id, _title, _slug, _content, _short_description, _category_id, _status, _final_image, NOW(), NOW())
    RETURNING id INTO _inserted_article_id;

    IF _inserted_article_id IS NULL THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Не удалось создать запись статьи.'::TEXT;
        RETURN;
    END IF;

    IF _tags IS NOT NULL AND array_length(_tags, 1) > 0 THEN
        FOREACH _tag_name IN ARRAY _tags LOOP
                _tag_name := TRIM(_tag_name);
                IF _tag_name <> '' THEN
                    SELECT id INTO _tag_id FROM Tags WHERE lower(name) = lower(_tag_name);
                    IF NOT FOUND THEN
                        INSERT INTO Tags (name) VALUES (_tag_name)
                        ON CONFLICT (name) DO NOTHING
                        RETURNING id INTO _tag_id;
                        IF _tag_id IS NULL THEN
                            SELECT id INTO _tag_id FROM Tags WHERE lower(name) = lower(_tag_name);
                        END IF;
                    END IF;

                    IF _tag_id IS NOT NULL THEN
                        INSERT INTO Article_tags (article_id, tag_id)
                        VALUES (_inserted_article_id, _tag_id)
                        ON CONFLICT (article_id, tag_id) DO NOTHING;
                    ELSE
                        RAISE WARNING 'Не удалось найти или создать тег: %', _tag_name;
                    END IF;
                END IF;
            END LOOP;
    END IF;

    RETURN QUERY SELECT _inserted_article_id, 'OK'::TEXT, 'Статья успешно создана.'::TEXT;

EXCEPTION
    WHEN unique_violation THEN
        RAISE WARNING 'Ошибка уникальности при создании статьи: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Не удалось создать статью из-за нарушения уникальности (заголовок или slug).';
    WHEN foreign_key_violation THEN
        RAISE WARNING 'Ошибка внешнего ключа при создании статьи: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Не удалось создать статью: неверный user_id или category_id.';
    WHEN invalid_text_representation THEN
        RAISE WARNING 'Неверное значение enum при создании статьи: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Указано недопустимое значение статуса.';
    WHEN OTHERS THEN
        RAISE WARNING 'Ошибка при создании статьи: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Произошла непредвиденная ошибка при создании статьи: ' || SQLERRM::TEXT;
END;
$$;

alter function create_article(integer, varchar, text, text, text, integer, article_status, varchar, text[]) owner to postgres;

grant execute on function create_article(integer, varchar, text, text, text, integer, article_status, varchar, text[]) to "Админ";

grant execute on function create_article(integer, varchar, text, text, text, integer, article_status, varchar, text[]) to "Модератор";

grant execute on function create_article(integer, varchar, text, text, text, integer, article_status, varchar, text[]) to "Пользователь";

