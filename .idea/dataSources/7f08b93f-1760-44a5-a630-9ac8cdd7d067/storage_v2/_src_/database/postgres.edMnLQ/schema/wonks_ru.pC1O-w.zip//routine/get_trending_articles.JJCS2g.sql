create function get_trending_articles(_time_period interval DEFAULT '7 days'::interval, _limit integer DEFAULT 5)
    returns TABLE(id integer, slug text, title text, short_description text, image text, created_at timestamp with time zone, category_name text, author_username text, rating numeric, comment_count bigint, trend_score numeric)
    stable
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        WITH ArticleScores AS (
            SELECT
                a.id,
                a.slug,
                a.title,
                a.short_description,
                a.image,
                a.created_at,
                cat.name AS category_name,
                u.username AS author_username,
                COALESCE((SELECT ROUND(AVG(r.value)::numeric, 2) FROM Ratings r WHERE r.article_id = a.id), 0) AS avg_rating,
                (SELECT COUNT(*) FROM Comments cm WHERE cm.article_id = a.id AND cm.created_at >= NOW() - _time_period) AS recent_comment_count
            FROM Articles a
                     JOIN Users u ON a.user_id = u.id
                     JOIN Categories cat ON a.category_id = cat.id
            WHERE a.status = 'published' AND a.created_at >= NOW() - _time_period
        )
        SELECT
            s.id,
            s.slug::TEXT,
            s.title::TEXT,
            s.short_description::TEXT,
            s.image::TEXT,
            s.created_at,
            s.category_name::TEXT,
            s.author_username::TEXT,
            s.avg_rating AS rating,
            s.recent_comment_count AS comment_count,
            (s.avg_rating * 0.6 + s.recent_comment_count * 0.4) AS trend_score
        FROM ArticleScores s
        ORDER BY trend_score DESC, s.created_at DESC
        LIMIT _limit;
END;
$$;

alter function get_trending_articles(interval, integer) owner to postgres;

grant execute on function get_trending_articles(interval, integer) to "Админ";

grant execute on function get_trending_articles(interval, integer) to "Модератор";

grant execute on function get_trending_articles(interval, integer) to "Пользователь";

grant execute on function get_trending_articles(interval, integer) to "Гость";

