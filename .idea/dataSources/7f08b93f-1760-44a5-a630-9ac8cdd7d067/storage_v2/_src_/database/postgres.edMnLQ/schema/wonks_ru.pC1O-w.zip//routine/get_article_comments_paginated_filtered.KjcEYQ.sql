create function get_article_comments_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_article_slug text DEFAULT NULL::text, filter_username text DEFAULT NULL::text, filter_content text DEFAULT NULL::text, filter_created_at_start timestamp with time zone DEFAULT NULL::timestamp with time zone, filter_created_at_end timestamp with time zone DEFAULT NULL::timestamp with time zone)
    returns TABLE(comment_id integer, article_slug text, username text, content text, created_at timestamp with time zone)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN
    query := 'SELECT comment_id, article_slug, username, content, created_at
              FROM view_article_comments';

    IF filter_article_slug IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('article_slug = %L', filter_article_slug));
    END IF;
    IF filter_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('username = %L', filter_username));
    END IF;
    IF filter_content IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('content ILIKE %L', '%' || filter_content || '%'));
    END IF;
    IF filter_created_at_start IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at >= %L', filter_created_at_start));
    END IF;
    IF filter_created_at_end IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at <= %L', filter_created_at_end));
    END IF;

    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;

    query := query || format(' ORDER BY created_at DESC LIMIT %L OFFSET %L', _limit, _offset);
    RAISE NOTICE 'Executing query: %', query;
    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_article_comments_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) owner to postgres;

grant execute on function get_article_comments_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Админ";

grant execute on function get_article_comments_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Модератор";

grant execute on function get_article_comments_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Пользователь";

grant execute on function get_article_comments_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Гость";

