create function authenticate_user(_identifier text, _plain_password text)
    returns TABLE(authenticated_user_id integer, user_role_id integer, username character varying, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _user_record RECORD;
BEGIN
    SELECT
        id,
        password_hash,
        role_id,
        status,
        u.username
    INTO _user_record
    FROM Users u
    WHERE lower(u.email) = lower(_identifier) OR lower(u.username) = lower(_identifier);

    IF NOT FOUND THEN
        RETURN QUERY SELECT NULL::INTEGER, NULL::INTEGER, NULL::VARCHAR, 'NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;

    IF _user_record.status <> 'activated' THEN
        RETURN QUERY SELECT NULL::INTEGER, NULL::INTEGER, NULL::VARCHAR, 'INACTIVE'::TEXT, 'User account is not active.'::TEXT;
        RETURN;
    END IF;

    IF _user_record.password_hash = crypt(_plain_password, _user_record.password_hash) THEN
        RETURN QUERY SELECT
                         _user_record.id,
                         _user_record.role_id,
                         _user_record.username,
                         'OK'::TEXT,
                         'Authentication successful.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, NULL::INTEGER, NULL::VARCHAR, 'WRONG_PASSWORD'::TEXT, 'Incorrect password.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error during user authentication: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, NULL::INTEGER, NULL::VARCHAR, 'ERROR'::TEXT, 'An unexpected error occurred during authentication: ' || SQLERRM::TEXT;
END;
$$;

alter function authenticate_user(text, text) owner to postgres;

grant execute on function authenticate_user(text, text) to "Админ";

grant execute on function authenticate_user(text, text) to "Модератор";

grant execute on function authenticate_user(text, text) to "Пользователь";

grant execute on function authenticate_user(text, text) to "Гость";

