create function get_article_details(_slug text)
    returns TABLE(id integer, slug text, title text, content text, short_description text, created_at timestamp with time zone, updated_at timestamp with time zone, image text, status article_status, category_id integer, category_name text, author_id integer, author_username text, author_avatar text, tags text[], rating numeric, comment_count bigint, favourite_count bigint)
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            a.id,
            a.slug::TEXT,
            a.title::TEXT,
            a.content::TEXT,
            a.short_description::TEXT,
            a.created_at,
            a.updated_at,
            a.image::TEXT,
            a.status,
            a.category_id,
            c.name::TEXT AS category_name,
            u.id AS author_id,
            u.username::TEXT AS author_username,
            u.avatar_url::TEXT AS author_avatar,
            COALESCE(array_agg(DISTINCT t.name::TEXT) FILTER (WHERE t.name IS NOT NULL), '{}') AS tags,
            COALESCE(ROUND(AVG(r.value)::numeric, 2), 0) AS rating,
            (SELECT COUNT(*) FROM Comments cm WHERE cm.article_id = a.id) AS comment_count,
            (SELECT COUNT(*) FROM Favourites f WHERE f.article_id = a.id) AS favourite_count
        FROM Articles a
                 JOIN Users u ON a.user_id = u.id
                 JOIN Categories c ON a.category_id = c.id
                 LEFT JOIN Article_tags at ON a.id = at.article_id
                 LEFT JOIN Tags t ON at.tag_id = t.id
                 LEFT JOIN Ratings r ON a.id = r.article_id
        WHERE a.slug = _slug
        GROUP BY a.id, u.id, c.id;
END;
$$;

alter function get_article_details(text) owner to postgres;

grant execute on function get_article_details(text) to "Админ";

grant execute on function get_article_details(text) to "Модератор";

grant execute on function get_article_details(text) to "Пользователь";

grant execute on function get_article_details(text) to "Гость";

