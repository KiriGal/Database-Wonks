create view view_user_notification (notification_id, recipient_id, recipient_username, text, created_at, is_read) as
SELECT n.id             AS notification_id,
       u.id             AS recipient_id,
       u.username::text AS recipient_username,
       n.text,
       n.created_at,
       n.is_read
FROM notifications n
         JOIN users u ON n.user_id = u.id
ORDER BY n.created_at DESC, n.id DESC;

alter table view_user_notification
    owner to postgres;

