create function check_user_rating(_user_id integer, _article_id integer) returns integer
    stable
    security definer
    language sql
as
$$
SELECT value FROM Ratings WHERE user_id = _user_id AND article_id = _article_id LIMIT 1;
$$;

alter function check_user_rating(integer, integer) owner to postgres;

grant execute on function check_user_rating(integer, integer) to "Админ";

grant execute on function check_user_rating(integer, integer) to "Модератор";

grant execute on function check_user_rating(integer, integer) to "Пользователь";

