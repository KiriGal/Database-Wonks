create function get_user_comments(_user_id integer, _limit integer DEFAULT 10, _offset integer DEFAULT 0)
    returns TABLE(comment_id integer, article_id integer, article_slug text, article_title text, content text, created_at timestamp with time zone)
    stable
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            c.id AS comment_id,
            c.article_id,
            a.slug::TEXT AS article_slug,
            a.title::TEXT AS article_title,
            c.content::TEXT,
            c.created_at
        FROM Comments c
                 JOIN Articles a ON c.article_id = a.id
        WHERE c.user_id = _user_id
        ORDER BY c.created_at DESC
        LIMIT _limit
            OFFSET _offset;
END;
$$;

alter function get_user_comments(integer, integer, integer) owner to postgres;

grant execute on function get_user_comments(integer, integer, integer) to "Админ";

grant execute on function get_user_comments(integer, integer, integer) to "Модератор";

grant execute on function get_user_comments(integer, integer, integer) to "Пользователь";

grant execute on function get_user_comments(integer, integer, integer) to "Гость";

