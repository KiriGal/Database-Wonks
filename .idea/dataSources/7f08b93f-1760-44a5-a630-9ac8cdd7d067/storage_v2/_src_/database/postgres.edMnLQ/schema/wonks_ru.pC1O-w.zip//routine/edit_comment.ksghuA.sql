create function edit_comment(_comment_id integer, _user_id integer, _new_content text)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _original_author_id INTEGER;
    _trimmed_content TEXT;
    _row_count INTEGER;
BEGIN
    SELECT user_id INTO _original_author_id FROM Comments WHERE id = _comment_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Comment not found.'::TEXT;
        RETURN;
    END IF;

    IF _original_author_id <> _user_id THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You do not have permission to edit this comment.'::TEXT;
        RETURN;
    END IF;

    _trimmed_content := TRIM(_new_content);
    IF _trimmed_content IS NULL OR _trimmed_content = '' THEN
        RETURN QUERY SELECT 'EMPTY_CONTENT'::TEXT, 'Comment content cannot be empty.'::TEXT;
        RETURN;
    END IF;

    UPDATE Comments
    SET content = _trimmed_content
    WHERE id = _comment_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Comment updated successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update comment, possibly due to concurrent deletion.'::TEXT;
    END IF;


EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error editing comment: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while editing the comment: ' || SQLERRM::TEXT;
END;
$$;

alter function edit_comment(integer, integer, text) owner to postgres;

grant execute on function edit_comment(integer, integer, text) to "Админ";

grant execute on function edit_comment(integer, integer, text) to "Модератор";

grant execute on function edit_comment(integer, integer, text) to "Пользователь";

