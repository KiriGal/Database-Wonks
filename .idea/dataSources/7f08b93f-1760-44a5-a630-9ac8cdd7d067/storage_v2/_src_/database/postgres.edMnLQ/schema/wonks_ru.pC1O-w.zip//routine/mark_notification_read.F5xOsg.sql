create function mark_notification_read(_notification_id integer, _user_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _notification_recipient_id INTEGER;
    _current_read_status BOOLEAN;
    _row_count INTEGER;
BEGIN
    SELECT user_id, is_read INTO _notification_recipient_id, _current_read_status
    FROM Notifications
    WHERE id = _notification_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Notification not found.'::TEXT; RETURN; END IF;

    IF _notification_recipient_id <> _user_id THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You cannot mark this notification.'::TEXT; RETURN; END IF;

    IF _current_read_status = true THEN RETURN QUERY SELECT 'ALREADY_READ'::TEXT, 'Notification is already marked as read.'::TEXT; RETURN; END IF;

    UPDATE Notifications SET is_read = true WHERE id = _notification_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN RETURN QUERY SELECT 'OK'::TEXT, 'Notification marked as read.'::TEXT;
    ELSE RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update notification status.'; END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error marking notification % read by user %: %', _notification_id, _user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function mark_notification_read(integer, integer) owner to postgres;

grant execute on function mark_notification_read(integer, integer) to "Админ";

grant execute on function mark_notification_read(integer, integer) to "Модератор";

grant execute on function mark_notification_read(integer, integer) to "Пользователь";

