create function get_tag_by_name(_name text) returns integer
    stable
    security definer
    language sql
as
$$
SELECT id FROM Tags WHERE lower(name) = lower(_name) LIMIT 1;
$$;

alter function get_tag_by_name(text) owner to postgres;

grant execute on function get_tag_by_name(text) to "Админ";

grant execute on function get_tag_by_name(text) to "Модератор";

grant execute on function get_tag_by_name(text) to "Пользователь";

grant execute on function get_tag_by_name(text) to "Гость";

