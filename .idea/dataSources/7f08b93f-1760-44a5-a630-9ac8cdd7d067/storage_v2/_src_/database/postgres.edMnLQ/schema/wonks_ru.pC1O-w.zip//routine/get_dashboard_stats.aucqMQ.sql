create function get_dashboard_stats() returns jsonb
    security definer
    language plpgsql
as
$$
DECLARE
    _stats JSONB := '{}'::jsonb;
    _users_by_status JSONB;
    _articles_by_status JSONB;
    _reports_by_status JSONB;
    _top_rated_articles JSONB;
    _most_commented_articles JSONB;
    _most_favourited_articles JSONB;
BEGIN
    _stats := _stats || jsonb_build_object(
            'total_users', (SELECT COUNT(*) FROM Users),
            'total_articles', (SELECT COUNT(*) FROM Articles),
            'total_comments', (SELECT COUNT(*) FROM Comments),
            'total_categories', (SELECT COUNT(*) FROM Categories),
            'total_tags', (SELECT COUNT(*) FROM Tags),
            'total_reports', (SELECT COUNT(*) FROM Reports),
            'total_subscriptions', (SELECT COUNT(*) FROM Subscriptions)
                        );

    SELECT jsonb_object_agg(status::text, count)
    INTO _users_by_status
    FROM (SELECT status, COUNT(*) AS count FROM Users GROUP BY status) AS sub;
    _stats := _stats || jsonb_build_object('users_by_status', COALESCE(_users_by_status, '{}'::jsonb));

    SELECT jsonb_object_agg(status::text, count)
    INTO _articles_by_status
    FROM (SELECT status, COUNT(*) AS count FROM Articles GROUP BY status) AS sub;
    _stats := _stats || jsonb_build_object('articles_by_status', COALESCE(_articles_by_status, '{}'::jsonb));

    SELECT jsonb_object_agg(status::text, count)
    INTO _reports_by_status
    FROM (SELECT status, COUNT(*) AS count FROM Reports GROUP BY status) AS sub;
    _stats := _stats || jsonb_build_object('reports_by_status', COALESCE(_reports_by_status, '{}'::jsonb));

    SELECT COALESCE(jsonb_agg(row_to_json(t)), '[]'::jsonb)
    INTO _top_rated_articles
    FROM (
             SELECT a.id, a.title, COALESCE(ROUND(AVG(r.value)::numeric, 2), 0) as avg_rating
             FROM Articles a
                      LEFT JOIN Ratings r ON a.id = r.article_id
             GROUP BY a.id, a.title
             ORDER BY avg_rating DESC, a.id
             LIMIT 5
         ) t;
    _stats := _stats || jsonb_build_object('top_rated_articles', _top_rated_articles);

    SELECT COALESCE(jsonb_agg(row_to_json(t)), '[]'::jsonb)
    INTO _most_commented_articles
    FROM (
             SELECT a.id, a.title, COUNT(c.id) as comment_count
             FROM Articles a
                      LEFT JOIN Comments c ON a.id = c.article_id
             GROUP BY a.id, a.title
             ORDER BY comment_count DESC, a.id
             LIMIT 5
         ) t;
    _stats := _stats || jsonb_build_object('most_commented_articles', _most_commented_articles);

    SELECT COALESCE(jsonb_agg(row_to_json(t)), '[]'::jsonb)
    INTO _most_favourited_articles
    FROM (
             SELECT a.id, a.title, COUNT(f.id) as favourite_count
             FROM Articles a
                      LEFT JOIN Favourites f ON a.id = f.article_id
             GROUP BY a.id, a.title
             ORDER BY favourite_count DESC, a.id
             LIMIT 5
         ) t;
    _stats := _stats || jsonb_build_object('most_favourited_articles', _most_favourited_articles);

    RETURN _stats;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error generating dashboard stats: %', SQLERRM;
        RETURN jsonb_build_object('error', 'Failed to generate statistics: ' || SQLERRM::TEXT);
END;
$$;

alter function get_dashboard_stats() owner to postgres;

grant execute on function get_dashboard_stats() to "Админ";

