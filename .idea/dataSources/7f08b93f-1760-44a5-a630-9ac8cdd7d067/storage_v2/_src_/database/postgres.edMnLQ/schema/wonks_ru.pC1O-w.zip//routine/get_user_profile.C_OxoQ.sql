create function get_user_profile(_user_id integer)
    returns TABLE(id integer, username text, avatar_url text, role_name text, status user_status, registered_at timestamp with time zone, last_login timestamp with time zone, article_count bigint, comment_count bigint, follower_count bigint, following_count bigint)
    security definer
    language plpgsql
as
$$
DECLARE
    _created_at_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'wonks_ru' AND table_name = 'users' AND column_name = 'created_at'
    ) INTO _created_at_exists;

    RETURN QUERY
        SELECT
            u.id,
            u.username::TEXT,
            u.avatar_url::TEXT,
            r.name::TEXT AS role_name,
            u.status,
            CASE WHEN _created_at_exists THEN (SELECT u2.created_at FROM users u2 WHERE u2.id = u.id) ELSE NULL END::TIMESTAMPTZ AS registered_at,
            u.last_login,
            (SELECT COUNT(*) FROM Articles a WHERE a.user_id = u.id) AS article_count,
            (SELECT COUNT(*) FROM Comments c WHERE c.user_id = u.id) AS comment_count,
            (SELECT COUNT(*) FROM Subscriptions s_in WHERE s_in.followed_id = u.id) AS follower_count,
            (SELECT COUNT(*) FROM Subscriptions s_out WHERE s_out.follower_id = u.id) AS following_count
        FROM Users u
                 JOIN Roles r ON u.role_id = r.id
        WHERE u.id = _user_id;
END;
$$;

alter function get_user_profile(integer) owner to postgres;

grant execute on function get_user_profile(integer) to "Админ";

grant execute on function get_user_profile(integer) to "Модератор";

grant execute on function get_user_profile(integer) to "Пользователь";

grant execute on function get_user_profile(integer) to "Гость";

