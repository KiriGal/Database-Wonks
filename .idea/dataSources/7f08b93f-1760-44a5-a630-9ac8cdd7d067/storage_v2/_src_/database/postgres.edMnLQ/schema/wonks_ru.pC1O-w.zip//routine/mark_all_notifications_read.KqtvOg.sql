create function mark_all_notifications_read(_user_id integer)
    returns TABLE(updated_count integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _row_count INTEGER;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT 0, 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT; RETURN;
    END IF;

    UPDATE Notifications
    SET is_read = true
    WHERE user_id = _user_id AND is_read = false;

    GET DIAGNOSTICS _row_count = ROW_COUNT;

    RETURN QUERY SELECT _row_count, 'OK'::TEXT, format('%s notifications marked as read for user %s.', _row_count, _user_id);

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error marking all notifications read for user %: %', _user_id, SQLERRM;
        RETURN QUERY SELECT 0, 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function mark_all_notifications_read(integer) owner to postgres;

grant execute on function mark_all_notifications_read(integer) to "Админ";

grant execute on function mark_all_notifications_read(integer) to "Модератор";

grant execute on function mark_all_notifications_read(integer) to "Пользователь";

