create function get_user_followers(_user_id integer, _limit integer DEFAULT 10, _offset integer DEFAULT 0)
    returns TABLE(follower_id integer, username text, avatar_url text)
    stable
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            s.follower_id,
            u.username::TEXT,
            u.avatar_url::TEXT
        FROM Subscriptions s
                 JOIN Users u ON s.follower_id = u.id
        WHERE s.followed_id = _user_id
        ORDER BY u.username
        LIMIT _limit
            OFFSET _offset;
END;
$$;

alter function get_user_followers(integer, integer, integer) owner to postgres;

grant execute on function get_user_followers(integer, integer, integer) to "Админ";

grant execute on function get_user_followers(integer, integer, integer) to "Модератор";

grant execute on function get_user_followers(integer, integer, integer) to "Пользователь";

grant execute on function get_user_followers(integer, integer, integer) to "Гость";

