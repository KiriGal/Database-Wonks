create function insert_articles() returns void
    language plpgsql
as
$$
DECLARE
    i INTEGER;
    s ARTICLE_STATUS; -- Используем правильный тип ENUM из определения таблицы
BEGIN
    FOR i IN 30..100000 LOOP
            -- Генерируем случайный статус из допустимых значений ENUM
            s := (ARRAY['moderated'::ARTICLE_STATUS,'published'::ARTICLE_STATUS,'rejected'::ARTICLE_STATUS])[floor(random() * 3 + 1)];

            -- Вставляем данные, явно перечисляя столбцы и добавляя short_description
            INSERT INTO articles (
                slug,
                user_id,
                content,
                short_description, -- <<< Добавлен недостающий столбец
                image,             -- Можно использовать DEFAULT или указать значение
                category_id,
                status,
                title
                -- created_at и updated_at получат значения по умолчанию NOW()
            )
            VALUES (
                       'slug_' || i,                     -- slug
                       1,                                -- user_id (пример)
                       'content_' || i,                  -- content
                       'short_description_' || i,        -- short_description (добавлено значение)
                       DEFAULT,                          -- image (используем значение по умолчанию)
                       1,                                -- category_id (пример)
                       s,                                -- status (случайный)
                       'title_' || i                     -- title
                   );
        END LOOP;
END;
$$;

alter function insert_articles() owner to postgres;

