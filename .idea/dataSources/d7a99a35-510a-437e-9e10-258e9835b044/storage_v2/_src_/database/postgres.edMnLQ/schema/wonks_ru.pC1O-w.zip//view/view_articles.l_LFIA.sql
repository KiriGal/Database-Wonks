create view view_articles
            (id, slug, title, content, short_description, created_at, updated_at, image, category_name, tags, rating) as
SELECT articles.id,
       articles.slug,
       articles.title::text                                                                           AS title,
       articles.content,
       articles.short_description,
       articles.created_at,
       articles.updated_at,
       articles.image::text                                                                           AS image,
       category.name::text                                                                            AS category_name,
       COALESCE(array_agg(DISTINCT tag.name::text) FILTER (WHERE tag.name IS NOT NULL), '{}'::text[]) AS tags,
       round(avg(rating.value), 2)                                                                    AS rating
FROM articles articles
         LEFT JOIN ratings rating ON articles.id = rating.article_id
         LEFT JOIN categories category ON articles.category_id = category.id
         LEFT JOIN article_tags article_tag ON articles.id = article_tag.article_id
         LEFT JOIN tags tag ON article_tag.tag_id = tag.id
GROUP BY articles.id, articles.slug, articles.title, articles.content, articles.short_description, articles.created_at,
         articles.updated_at, articles.image, category.name
ORDER BY articles.id DESC;

alter table view_articles
    owner to postgres;

