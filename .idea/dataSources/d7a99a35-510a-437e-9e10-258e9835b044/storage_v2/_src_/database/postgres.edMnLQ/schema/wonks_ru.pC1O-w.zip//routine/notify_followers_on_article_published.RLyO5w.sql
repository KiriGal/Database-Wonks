create function notify_followers_on_article_published() returns trigger
    security definer
    language plpgsql
as
$$
DECLARE
    follower RECORD;
BEGIN
    IF OLD.status IS DISTINCT FROM 'published' AND NEW.status = 'published' THEN
        FOR follower IN
            SELECT follower_id
            FROM wonks_ru.Subscriptions
            WHERE followed_id = NEW.follower_id
              AND notices = true
            LOOP
                INSERT INTO wonks_ru.Notifications(user_id, text)
                VALUES (follower.follower_id,
                        CONCAT(
                                'Пользователь, на которого вы подписаны, опубликовал статью "',
                                NEW.title, '".'
                        ));
            END LOOP;
    END IF;

    RETURN NEW;
END;
$$;

alter function notify_followers_on_article_published() owner to postgres;

