create view view_user_subscription (id, followed_id, follower_id, followed_username, follower_username, notices) as
SELECT sub.id,
       sub.followed_id,
       sub.follower_id,
       followed_user.username::text AS followed_username,
       follower_user.username::text AS follower_username,
       sub.notices
FROM subscriptions sub
         JOIN users followed_user ON sub.followed_id = followed_user.id
         JOIN users follower_user ON sub.follower_id = follower_user.id
ORDER BY sub.id DESC;

alter table view_user_subscription
    owner to postgres;

