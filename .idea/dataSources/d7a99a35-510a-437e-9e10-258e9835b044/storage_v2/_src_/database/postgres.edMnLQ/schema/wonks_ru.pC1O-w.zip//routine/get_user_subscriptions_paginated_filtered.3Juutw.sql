create function get_user_subscriptions_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_followed_id integer DEFAULT NULL::integer, filter_follower_id integer DEFAULT NULL::integer, filter_followed_username text DEFAULT NULL::text, filter_follower_username text DEFAULT NULL::text, filter_notices boolean DEFAULT NULL::boolean)
    returns TABLE(followed_id integer, follower_id integer, followed_username text, follower_username text, notices boolean)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN

    query := 'SELECT followed_id, follower_id, followed_username, follower_username, notices
              FROM wonks_ru.view_user_subscription';

    IF filter_followed_id IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('followed_id = %L', filter_followed_id));
    END IF;

    IF filter_follower_id IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('follower_id = %L', filter_follower_id));
    END IF;

    IF filter_followed_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('followed_username = %L', filter_followed_username));
    END IF;

    IF filter_follower_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('follower_username = %L', filter_follower_username));
    END IF;

    IF filter_notices IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('notices = %L', filter_notices));
    END IF;

    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;


    query := query ||
             format(' ORDER BY followed_username ASC, follower_username ASC LIMIT %L OFFSET %L', _limit, _offset);

    RAISE NOTICE 'Executing query: %', query;
    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_user_subscriptions_paginated_filtered(integer, integer, integer, integer, text, text, boolean) owner to postgres;

grant execute on function get_user_subscriptions_paginated_filtered(integer, integer, integer, integer, text, text, boolean) to "Админ";

grant execute on function get_user_subscriptions_paginated_filtered(integer, integer, integer, integer, text, text, boolean) to "Модератор";

grant execute on function get_user_subscriptions_paginated_filtered(integer, integer, integer, integer, text, text, boolean) to "Пользователь";

grant execute on function get_user_subscriptions_paginated_filtered(integer, integer, integer, integer, text, text, boolean) to "Гость";

