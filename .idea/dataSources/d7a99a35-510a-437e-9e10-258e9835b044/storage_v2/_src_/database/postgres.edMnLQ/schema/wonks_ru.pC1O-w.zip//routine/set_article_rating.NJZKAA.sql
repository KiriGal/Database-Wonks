create function set_article_rating(_user_id integer, _article_id integer, _rating_value integer)
    returns TABLE(rating_record_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _upserted_id INTEGER := NULL;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Articles WHERE id = _article_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    IF _rating_value < 1 OR _rating_value > 5 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'INVALID_RATING'::TEXT, 'Rating value must be between 1 and 5.'::TEXT;
        RETURN;
    END IF;

    INSERT INTO wonks_ru.Ratings (user_id, article_id, value)
    VALUES (_user_id, _article_id, _rating_value)
    ON CONFLICT (user_id, article_id)
        DO UPDATE SET
        value = EXCLUDED.value
    RETURNING id INTO _upserted_id;

    IF _upserted_id IS NOT NULL THEN
        RETURN QUERY SELECT _upserted_id, 'OK'::TEXT, 'Article rating set/updated successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to set/update rating record.'::TEXT;
    END IF;

EXCEPTION
    WHEN CHECK_VIOLATION THEN
        RAISE WARNING 'Check violation during rating: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'INVALID_RATING'::TEXT, 'Rating value is outside the allowed range (1-5).';
    WHEN OTHERS THEN
        RAISE WARNING 'Error setting rating: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred while setting the rating: ' || SQLERRM::TEXT;
END;
$$;

alter function set_article_rating(integer, integer, integer) owner to postgres;

grant execute on function set_article_rating(integer, integer, integer) to "Админ";

grant execute on function set_article_rating(integer, integer, integer) to "Модератор";

grant execute on function set_article_rating(integer, integer, integer) to "Пользователь";

