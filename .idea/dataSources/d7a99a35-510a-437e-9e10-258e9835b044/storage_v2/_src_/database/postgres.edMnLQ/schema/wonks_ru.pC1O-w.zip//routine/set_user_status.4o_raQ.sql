create function set_user_status(_target_user_id integer, _actor_user_id integer, _new_status user_status)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _target_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Moderator'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _actor_role_name
    FROM wonks_ru.Users u
             JOIN wonks_ru.Roles r ON u.role_id = r.id
    WHERE u.id = _actor_user_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'ACTOR_NOT_FOUND'::TEXT, 'Actor user not found or missing role.'::TEXT;
        RETURN;
    END IF;

    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to change user status.'::TEXT;
        RETURN;
    END IF;

    IF _actor_user_id = _target_user_id THEN
        RETURN QUERY SELECT 'CANNOT_BAN_SELF'::TEXT, 'Cannot change your own status.'::TEXT;
        RETURN;
    END IF;

    SELECT r.name INTO _target_role_name
    FROM wonks_ru.Users u
             JOIN wonks_ru.Roles r ON u.role_id = r.id
    WHERE u.id = _target_user_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'TARGET_NOT_FOUND'::TEXT, 'Target user not found.'::TEXT;
        RETURN;
    END IF;

    IF _target_role_name = 'Administrator' AND _new_status = 'banned' THEN
        RETURN QUERY SELECT 'CANNOT_BAN_ADMIN'::TEXT, 'Cannot ban another Administrator.'::TEXT;
        RETURN;
    END IF;

    UPDATE wonks_ru.Users
    SET status = _new_status
    WHERE id = _target_user_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('User %s status updated to %s successfully.', _target_user_id, _new_status);
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update user status, user might have been deleted concurrently.';
    END IF;

EXCEPTION
    WHEN invalid_text_representation THEN
        RAISE WARNING 'Invalid enum value during user status update: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Invalid status value provided.';
    WHEN OTHERS THEN
        RAISE WARNING 'Error setting user % status by user %: %', _target_user_id, _actor_user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while setting user status: ' || SQLERRM::TEXT;
END;
$$;

alter function set_user_status(integer, integer, user_status) owner to postgres;

grant execute on function set_user_status(integer, integer, user_status) to "Админ";

grant execute on function set_user_status(integer, integer, user_status) to "Модератор";

