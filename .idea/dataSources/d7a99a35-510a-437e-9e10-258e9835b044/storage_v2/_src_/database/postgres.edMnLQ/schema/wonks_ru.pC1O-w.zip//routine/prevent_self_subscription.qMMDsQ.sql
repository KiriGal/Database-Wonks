create function prevent_self_subscription() returns trigger
    security definer
    language plpgsql
as
$$
BEGIN
    IF NEW.follower_id = NEW.followed_id THEN
        RAISE EXCEPTION 'Пользователь не может подписаться сам на себя.';
    END IF;
    RETURN NEW;
END;
$$;

alter function prevent_self_subscription() owner to postgres;

