create function update_tag(_actor_user_id integer, _tag_id integer, _new_tag_name character varying)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Editor'];
    _current_name VARCHAR(255);
    _trimmed_new_name VARCHAR(255);
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _actor_role_name FROM wonks_ru.Users u JOIN wonks_ru.Roles r ON u.role_id = r.id WHERE u.id = _actor_user_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN; END IF;
    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to update tags.'::TEXT; RETURN; END IF;

    _trimmed_new_name := TRIM(_new_tag_name);
    IF _trimmed_new_name IS NULL OR _trimmed_new_name = '' THEN RETURN QUERY SELECT 'INVALID_INPUT'::TEXT, 'New tag name cannot be empty.'::TEXT; RETURN; END IF;

    SELECT name INTO _current_name FROM wonks_ru.Tags WHERE id = _tag_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Tag not found.'::TEXT; RETURN; END IF;

    IF lower(_current_name) = lower(_trimmed_new_name) THEN RETURN QUERY SELECT 'NO_CHANGES'::TEXT, 'New name is the same as the current name.'::TEXT; RETURN; END IF;

    IF EXISTS (SELECT 1 FROM wonks_ru.Tags WHERE lower(name) = lower(_trimmed_new_name) AND id <> _tag_id) THEN
        RETURN QUERY SELECT 'NAME_EXISTS'::TEXT, 'New tag name already exists.'::TEXT; RETURN;
    END IF;

    UPDATE wonks_ru.Tags SET name = _trimmed_new_name WHERE id = _tag_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Tag updated successfully.';
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update tag, possibly deleted concurrently.';
    END IF;

EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT 'NAME_EXISTS'::TEXT, 'New tag name already exists (concurrent update).';
    WHEN OTHERS THEN
        RAISE WARNING 'Error updating tag % by user %: %', _tag_id, _actor_user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function update_tag(integer, integer, varchar) owner to postgres;

grant execute on function update_tag(integer, integer, varchar) to "Админ";

grant execute on function update_tag(integer, integer, varchar) to "Модератор";

