create function delete_comment(_comment_id integer, _user_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _original_author_id INTEGER;
    _row_count INTEGER;
BEGIN
    SELECT user_id INTO _original_author_id FROM wonks_ru.Comments WHERE id = _comment_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Comment not found.'::TEXT;
        RETURN;
    END IF;

    IF _original_author_id <> _user_id THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You do not have permission to delete this comment.'::TEXT;
        RETURN;
    END IF;

    DELETE FROM wonks_ru.Comments
    WHERE id = _comment_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Comment deleted successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to delete comment, possibly already deleted.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting comment: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while deleting the comment: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_comment(integer, integer) owner to postgres;

grant execute on function delete_comment(integer, integer) to "Админ";

grant execute on function delete_comment(integer, integer) to "Модератор";

grant execute on function delete_comment(integer, integer) to "Пользователь";

