create function add_to_favourites(_user_id integer, _article_id integer)
    returns TABLE(new_favourite_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _inserted_id INTEGER := NULL;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Articles WHERE id = _article_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    IF EXISTS (SELECT 1 FROM wonks_ru.Favourites WHERE user_id = _user_id AND article_id = _article_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ALREADY_EXISTS'::TEXT, 'Article is already in favourites.'::TEXT;
        RETURN;
    END IF;

    INSERT INTO wonks_ru.Favourites (user_id, article_id)
    VALUES (_user_id, _article_id)
    ON CONFLICT (user_id, article_id)
        DO NOTHING
    RETURNING id INTO _inserted_id;

    IF _inserted_id IS NOT NULL THEN
        RETURN QUERY SELECT _inserted_id, 'OK'::TEXT, 'Article added to favourites successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to add favourite record (or constraint violation occurred).'::TEXT;
    END IF;


EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error adding favourite: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred while adding favourite: ' || SQLERRM::TEXT;
END;
$$;

alter function add_to_favourites(integer, integer) owner to postgres;

grant execute on function add_to_favourites(integer, integer) to "Админ";

grant execute on function add_to_favourites(integer, integer) to "Модератор";

grant execute on function add_to_favourites(integer, integer) to "Пользователь";

