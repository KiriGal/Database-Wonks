create function export_schema_to_jsonb(_schema_name text DEFAULT 'wonks_ru'::text) returns jsonb
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
DECLARE
    _table_record RECORD;
    _table_jsonb JSONB;
    _result_jsonb JSONB := '{}'::jsonb;
    _query TEXT;
BEGIN
    FOR _table_record IN
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = _schema_name AND table_type = 'BASE TABLE'
        ORDER BY table_name
        LOOP
            _query := format(
                    'SELECT COALESCE(jsonb_agg(row_to_json(t)), ''[]''::jsonb) FROM %I.%I t',
                    _schema_name,
                    _table_record.table_name
                      );

            RAISE NOTICE 'Exporting table: %.%', _schema_name, _table_record.table_name;
            EXECUTE _query INTO _table_jsonb;

            _result_jsonb := _result_jsonb || jsonb_build_object(_table_record.table_name, _table_jsonb);
        END LOOP;

    RETURN _result_jsonb;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error during schema export: %', SQLERRM;
        RETURN jsonb_build_object('error', SQLERRM);
END;
$$;

alter function export_schema_to_jsonb(text) owner to postgres;

grant execute on function export_schema_to_jsonb(text) to "Админ";

