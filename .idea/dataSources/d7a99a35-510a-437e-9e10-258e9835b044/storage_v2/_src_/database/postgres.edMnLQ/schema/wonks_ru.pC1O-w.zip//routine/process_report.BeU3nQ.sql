create function process_report(_report_id integer, _processor_id integer, _new_status complaint_status)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _processor_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Moderator'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _processor_role_name
    FROM wonks_ru.Users u
             JOIN wonks_ru.Roles r ON u.role_id = r.id
    WHERE u.id = _processor_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'Processor user not found or missing role.'::TEXT;
        RETURN;
    END IF;

    IF NOT (_processor_role_name = ANY(_allowed_roles)) THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to process reports.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Reports WHERE id = _report_id) THEN
        RETURN QUERY SELECT 'REPORT_NOT_FOUND'::TEXT, 'Report not found.'::TEXT;
        RETURN;
    END IF;

    UPDATE wonks_ru.Reports
    SET status = _new_status
    WHERE id = _report_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('Report %s status updated to %s successfully.', _report_id, _new_status);
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update report status, it might have been deleted concurrently.';
    END IF;

EXCEPTION
    WHEN invalid_text_representation THEN
        RAISE WARNING 'Invalid enum value during report status update: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Invalid status value provided.';
    WHEN OTHERS THEN
        RAISE WARNING 'Error processing report % by user %: %', _report_id, _processor_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while processing the report: ' || SQLERRM::TEXT;
END;
$$;

alter function process_report(integer, integer, complaint_status) owner to postgres;

grant execute on function process_report(integer, integer, complaint_status) to "Админ";

grant execute on function process_report(integer, integer, complaint_status) to "Модератор";

