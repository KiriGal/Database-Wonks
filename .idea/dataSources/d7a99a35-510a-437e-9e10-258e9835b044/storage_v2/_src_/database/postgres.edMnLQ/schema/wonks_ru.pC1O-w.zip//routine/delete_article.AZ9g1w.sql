create function delete_article(_article_id integer, _user_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _original_author_id INTEGER;
    _row_count INTEGER;
BEGIN
    SELECT user_id INTO _original_author_id FROM wonks_ru.Articles WHERE id = _article_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    IF _original_author_id <> _user_id THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'You do not have permission to delete this article.'::TEXT;
        RETURN;
    END IF;

    DELETE FROM wonks_ru.Articles
    WHERE id = _article_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Article deleted successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to delete article, possibly already deleted.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting article: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during article deletion: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_article(integer, integer) owner to postgres;

grant execute on function delete_article(integer, integer) to "Админ";

grant execute on function delete_article(integer, integer) to "Модератор";

grant execute on function delete_article(integer, integer) to "Пользователь";

