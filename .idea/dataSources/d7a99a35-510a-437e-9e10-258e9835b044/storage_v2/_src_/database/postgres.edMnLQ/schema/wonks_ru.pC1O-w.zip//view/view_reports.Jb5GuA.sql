create view view_reports (report_id, target_id, reporter_username, target_username, content, status, date) as
SELECT r.id                    AS report_id,
       target.id               AS target_id,
       reporter.username::text AS reporter_username,
       target.username::text   AS target_username,
       r.content,
       r.status::text          AS status,
       r.date
FROM reports r
         JOIN users reporter ON r.reporter_id = reporter.id
         JOIN users target ON r.target_id = target.id
ORDER BY r.date DESC;

alter table view_reports
    owner to postgres;

