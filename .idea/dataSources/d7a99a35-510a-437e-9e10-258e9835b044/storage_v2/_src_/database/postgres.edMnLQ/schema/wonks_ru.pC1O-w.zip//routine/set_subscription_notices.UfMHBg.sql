create function set_subscription_notices(_follower_id integer, _followed_id integer, _enable_notices boolean)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _row_count INTEGER;
BEGIN
    UPDATE wonks_ru.Subscriptions
    SET notices = _enable_notices
    WHERE follower_id = _follower_id AND followed_id = _followed_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;

    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('Notification setting for following user %s set to %s.', _followed_id, _enable_notices);
    ELSE
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, format('Subscription from user %s to user %s not found.', _follower_id, _followed_id);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error setting subscription notices: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while setting notices: ' || SQLERRM::TEXT;
END;
$$;

alter function set_subscription_notices(integer, integer, boolean) owner to postgres;

grant execute on function set_subscription_notices(integer, integer, boolean) to "Админ";

grant execute on function set_subscription_notices(integer, integer, boolean) to "Модератор";

grant execute on function set_subscription_notices(integer, integer, boolean) to "Пользователь";

