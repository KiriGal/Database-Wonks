create function get_reports_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_reporter_username text DEFAULT NULL::text, filter_target_username text DEFAULT NULL::text, filter_status text DEFAULT NULL::text, filter_date_start timestamp with time zone DEFAULT NULL::timestamp with time zone, filter_date_end timestamp with time zone DEFAULT NULL::timestamp with time zone)
    returns TABLE(report_id integer, target_id integer, reporter_username text, target_username text, content text, status text, date timestamp with time zone)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN

    query := 'SELECT report_id, target_id, reporter_username, target_username, content, status, date
              FROM wonks_ru.view_reports';

    IF filter_reporter_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('reporter_username = %L', filter_reporter_username));
    END IF;

    IF filter_target_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('target_username = %L', filter_target_username));
    END IF;

    IF filter_status IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('status = %L', filter_status));
    END IF;

    IF filter_date_start IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('date >= %L', filter_date_start));
    END IF;

    IF filter_date_end IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('date <= %L', filter_date_end));
    END IF;


    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;


    query := query || format(' ORDER BY date DESC LIMIT %L OFFSET %L', _limit, _offset);

    RAISE NOTICE 'Executing query: %', query;
    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_reports_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) owner to postgres;

grant execute on function get_reports_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Админ";

grant execute on function get_reports_paginated_filtered(integer, integer, text, text, text, timestamp with time zone, timestamp with time zone) to "Модератор";

