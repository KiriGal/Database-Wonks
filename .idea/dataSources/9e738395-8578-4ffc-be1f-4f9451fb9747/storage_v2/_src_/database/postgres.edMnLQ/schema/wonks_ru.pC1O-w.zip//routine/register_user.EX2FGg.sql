create function register_user(_username character varying, _email character varying, _plain_password text)
    returns TABLE(registered_user_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _hashed_password TEXT;
    _user_role_id INTEGER;
    _existing_user_id INTEGER;
    _new_user_id INTEGER := NULL;
BEGIN
    SELECT id INTO _existing_user_id FROM wonks_ru.Users WHERE lower(email) = lower(_email);
    IF FOUND THEN
        RETURN QUERY SELECT NULL::INTEGER, 'EMAIL_EXISTS'::TEXT, 'Email already registered.'::TEXT;
        RETURN;
    END IF;

    SELECT id INTO _existing_user_id FROM wonks_ru.Users WHERE lower(username) = lower(_username);
    IF FOUND THEN
        RETURN QUERY SELECT NULL::INTEGER, 'USERNAME_EXISTS'::TEXT, 'Username already taken.'::TEXT;
        RETURN;
    END IF;

    SELECT id INTO _user_role_id FROM wonks_ru.Roles WHERE name = 'User';
    IF NOT FOUND THEN
        RAISE WARNING 'Default role "User" not found in wonks_ru.Roles table.';
        RETURN QUERY SELECT NULL::INTEGER, 'ROLE_NOT_FOUND'::TEXT, 'Default user role configuration error.'::TEXT;
        RETURN;
    END IF;

    _hashed_password := crypt(_plain_password, gen_salt('bf'));

    INSERT INTO wonks_ru.Users (username, email, password_hash, role_id)
    VALUES (_username, _email, _hashed_password, _user_role_id)
    RETURNING id INTO _new_user_id;

    IF _new_user_id IS NOT NULL THEN
        RETURN QUERY SELECT _new_user_id, 'OK'::TEXT, 'User registered successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to insert user record.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error during user registration: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred during registration: ' || SQLERRM::TEXT;
END;
$$;

alter function register_user(varchar, varchar, text) owner to postgres;

grant execute on function register_user(varchar, varchar, text) to "Гость";

