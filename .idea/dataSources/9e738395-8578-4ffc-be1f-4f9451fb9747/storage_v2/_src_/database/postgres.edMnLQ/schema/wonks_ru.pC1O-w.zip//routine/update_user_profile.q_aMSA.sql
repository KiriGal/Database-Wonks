create function update_user_profile(_user_id integer, _new_username character varying DEFAULT NULL::character varying, _new_email character varying DEFAULT NULL::character varying, _new_avatar_url character varying DEFAULT NULL::character varying)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _current_username VARCHAR(255);
    _current_email VARCHAR(255);
    _update_clauses TEXT[] := '{}';
    _query TEXT;
BEGIN
    RAISE NOTICE '[DEBUG] Entering function for user_id: %', _user_id;

    SELECT username, email INTO _current_username, _current_email
    FROM wonks_ru.Users WHERE id = _user_id;
    IF NOT FOUND THEN
        RAISE NOTICE '[DEBUG] User not found. Returning USER_NOT_FOUND.';
        RETURN QUERY SELECT 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;
    RAISE NOTICE '[DEBUG] User found: %, %', _current_username, _current_email;

    IF _new_username IS NOT NULL AND _new_username <> _current_username THEN
        IF EXISTS (SELECT 1 FROM wonks_ru.Users WHERE lower(username) = lower(_new_username) AND id <> _user_id) THEN
            RAISE NOTICE '[DEBUG] New username exists. Returning USERNAME_EXISTS.';
            RETURN QUERY SELECT 'USERNAME_EXISTS'::TEXT, 'New username is already taken.'::TEXT;
            RETURN;
        END IF;
        _update_clauses := array_append(_update_clauses, format('username = %L', _new_username));
        RAISE NOTICE '[DEBUG] Added username to clauses.';
    END IF;
    IF _new_email IS NOT NULL AND _new_email <> _current_email THEN
        IF EXISTS (SELECT 1 FROM wonks_ru.Users WHERE lower(email) = lower(_new_email) AND id <> _user_id) THEN
            RAISE NOTICE '[DEBUG] New email exists. Returning EMAIL_EXISTS.';
            RETURN QUERY SELECT 'EMAIL_EXISTS'::TEXT, 'New email is already registered.'::TEXT;
            RETURN;
        END IF;
        _update_clauses := array_append(_update_clauses, format('email = %L', _new_email));
        RAISE NOTICE '[DEBUG] Added email to clauses.';
    END IF;
    IF _new_avatar_url IS NOT NULL THEN
        _update_clauses := array_append(_update_clauses, format('avatar_url = %L', _new_avatar_url));
        RAISE NOTICE '[DEBUG] Added avatar_url to clauses.';
    END IF;

    RAISE NOTICE '[DEBUG] Finished clause assembly. Clause count: %', array_length(_update_clauses, 1);

    IF array_length(_update_clauses, 1) IS NULL OR array_length(_update_clauses, 1) = 0 THEN
        RAISE NOTICE '[DEBUG] No update clauses. Returning NO_CHANGES.';
        RETURN QUERY SELECT 'NO_CHANGES'::TEXT, 'No changes requested.'::TEXT;
        RAISE NOTICE '[DEBUG] This notice should NOT appear if RETURN worked.';
        RETURN;
    END IF;

    RAISE NOTICE '[DEBUG] Proceeding to build and execute UPDATE query.';
    _query := format('UPDATE wonks_ru.Users SET %s WHERE id = %L',
                     array_to_string(_update_clauses, ', '),
                     _user_id);

    RAISE NOTICE '[DEBUG] Executing query: %', _query;
    EXECUTE _query;

    RAISE NOTICE '[DEBUG] Update successful. Returning OK.';
    RETURN QUERY SELECT 'OK'::TEXT, 'User profile updated successfully.'::TEXT;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING '[USER_ID: %] Exception during update: %', _user_id, SQLERRM;
        RAISE NOTICE '[DEBUG] Exception occurred. Returning ERROR.';
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during profile update: ' || SQLERRM::TEXT;
END;
$$;

alter function update_user_profile(integer, varchar, varchar, varchar) owner to postgres;

grant execute on function update_user_profile(integer, varchar, varchar, varchar) to "Админ";

grant execute on function update_user_profile(integer, varchar, varchar, varchar) to "Модератор";

grant execute on function update_user_profile(integer, varchar, varchar, varchar) to "Пользователь";

