create function get_user_notifications_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_recipient_id integer DEFAULT NULL::integer, filter_recipient_username text DEFAULT NULL::text, filter_text text DEFAULT NULL::text, filter_created_at_start timestamp with time zone DEFAULT NULL::timestamp with time zone, filter_created_at_end timestamp with time zone DEFAULT NULL::timestamp with time zone)
    returns TABLE(notification_id integer, recipient_id integer, recipient_username text, text text, created_at timestamp with time zone)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN

    query := 'SELECT notification_id, recipient_id, recipient_username, text, created_at
              FROM wonks_ru.view_user_notification';

    IF filter_recipient_id IS NOT NULL THEN

        where_clauses := array_append(where_clauses, format('recipient_id = %L', filter_recipient_id));
    END IF;

    IF filter_recipient_username IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('recipient_username = %L', filter_recipient_username));
    END IF;

    IF filter_text IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('text ILIKE %L', '%' || filter_text || '%'));
    END IF;

    IF filter_created_at_start IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at >= %L', filter_created_at_start));
    END IF;

    IF filter_created_at_end IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at <= %L', filter_created_at_end));
    END IF;


    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;


    query := query || format(' ORDER BY created_at DESC, notification_id DESC LIMIT %L OFFSET %L', _limit, _offset);

    RAISE NOTICE 'Executing query: %', query;
    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_user_notifications_paginated_filtered(integer, integer, integer, text, text, timestamp with time zone, timestamp with time zone) owner to postgres;

grant execute on function get_user_notifications_paginated_filtered(integer, integer, integer, text, text, timestamp with time zone, timestamp with time zone) to "Админ";

grant execute on function get_user_notifications_paginated_filtered(integer, integer, integer, text, text, timestamp with time zone, timestamp with time zone) to "Модератор";

grant execute on function get_user_notifications_paginated_filtered(integer, integer, integer, text, text, timestamp with time zone, timestamp with time zone) to "Пользователь";

