create function notify_article_author_on_comment() returns trigger
    security definer
    language plpgsql
as
$$
DECLARE
    article_owner_id   INTEGER;
    commenter_username VARCHAR(255);
BEGIN
    SELECT user_id INTO article_owner_id FROM wonks_ru.Articles WHERE id = NEW.article_id;
    SELECT username INTO commenter_username FROM wonks_ru.Users WHERE id = NEW.user_id;

    IF article_owner_id <> NEW.user_id THEN
        INSERT INTO wonks_ru.Notifications(user_id, text)
        VALUES (article_owner_id, CONCAT('Новый комментарий от пользователя ', commenter_username, ' к вашей статье.'));
    END IF;
    RETURN NEW;
END;
$$;

alter function notify_article_author_on_comment() owner to postgres;

