create function delete_all_user_notifications(_user_id integer)
    returns TABLE(deleted_count integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _row_count INTEGER;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _user_id) THEN
        RETURN QUERY SELECT 0, 'USER_NOT_FOUND'::TEXT, 'User not found.'::TEXT;
        RETURN;
    END IF;

    DELETE FROM wonks_ru.Notifications
    WHERE user_id = _user_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;

    RETURN QUERY SELECT _row_count, 'OK'::TEXT, format('%s notifications deleted for user %s.', _row_count, _user_id);

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting all user notifications for user %: %', _user_id, SQLERRM;
        RETURN QUERY SELECT 0, 'ERROR'::TEXT, 'An unexpected error occurred while deleting notifications: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_all_user_notifications(integer) owner to postgres;

grant execute on function delete_all_user_notifications(integer) to "Админ";

grant execute on function delete_all_user_notifications(integer) to "Модератор";

grant execute on function delete_all_user_notifications(integer) to "Пользователь";

