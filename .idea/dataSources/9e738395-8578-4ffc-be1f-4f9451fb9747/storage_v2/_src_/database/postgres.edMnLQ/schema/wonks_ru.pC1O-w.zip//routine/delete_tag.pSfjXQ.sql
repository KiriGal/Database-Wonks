create function delete_tag(_actor_user_id integer, _tag_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Editor'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _actor_role_name FROM wonks_ru.Users u JOIN wonks_ru.Roles r ON u.role_id = r.id WHERE u.id = _actor_user_id;
    IF NOT FOUND THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN; END IF;
    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to delete tags.'::TEXT; RETURN; END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Tags WHERE id = _tag_id) THEN
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'Tag not found.'::TEXT; RETURN;
    END IF;

    IF EXISTS (SELECT 1 FROM wonks_ru.Article_tags WHERE tag_id = _tag_id) THEN
        RETURN QUERY SELECT 'HAS_ARTICLES'::TEXT, 'Cannot delete tag because it is currently assigned to one or more articles.'::TEXT;
        RETURN;
    END IF;

    DELETE FROM wonks_ru.Tags WHERE id = _tag_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Tag deleted successfully.';
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to delete tag, possibly already deleted.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error deleting tag % by user %: %', _tag_id, _actor_user_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function delete_tag(integer, integer) owner to postgres;

grant execute on function delete_tag(integer, integer) to "Админ";

grant execute on function delete_tag(integer, integer) to "Модератор";

