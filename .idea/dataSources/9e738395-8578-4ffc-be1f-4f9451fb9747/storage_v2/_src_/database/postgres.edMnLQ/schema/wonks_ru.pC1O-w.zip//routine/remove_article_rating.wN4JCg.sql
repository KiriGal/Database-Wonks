create function remove_article_rating(_user_id integer, _article_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _row_count INTEGER;
BEGIN
    DELETE FROM wonks_ru.Ratings
    WHERE user_id = _user_id AND article_id = _article_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;

    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Article rating removed successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'NOT_FOUND'::TEXT, 'No rating found for this user and article.'::TEXT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error removing rating: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while removing the rating: ' || SQLERRM::TEXT;
END;
$$;

alter function remove_article_rating(integer, integer) owner to postgres;

grant execute on function remove_article_rating(integer, integer) to "Админ";

grant execute on function remove_article_rating(integer, integer) to "Модератор";

grant execute on function remove_article_rating(integer, integer) to "Пользователь";

