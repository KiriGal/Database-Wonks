create function unsubscribe_from_user(_follower_id integer, _followed_id integer)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _row_count INTEGER;
BEGIN
    IF _follower_id = _followed_id THEN
        RETURN QUERY SELECT 'SELF_UNSUBSCRIPTION'::TEXT, 'Cannot unsubscribe from yourself.'::TEXT; RETURN;
    END IF;

    DELETE FROM wonks_ru.Subscriptions
    WHERE follower_id = _follower_id AND followed_id = _followed_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, 'Successfully unsubscribed.'::TEXT;
    ELSE
        RETURN QUERY SELECT 'NOT_SUBSCRIBED'::TEXT, 'Was not subscribed to this user.'::TEXT;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error during unsubscription: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during unsubscription: ' || SQLERRM::TEXT;
END;
$$;

alter function unsubscribe_from_user(integer, integer) owner to postgres;

grant execute on function unsubscribe_from_user(integer, integer) to "Админ";

grant execute on function unsubscribe_from_user(integer, integer) to "Модератор";

grant execute on function unsubscribe_from_user(integer, integer) to "Пользователь";

