create function create_category(_actor_user_id integer, _category_name character varying)
    returns TABLE(new_category_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _actor_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Editor'];
    _trimmed_name VARCHAR(255);
    _inserted_id INTEGER := NULL;
BEGIN
    SELECT r.name INTO _actor_role_name FROM wonks_ru.Users u JOIN wonks_ru.Roles r ON u.role_id = r.id WHERE u.id = _actor_user_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT NULL::INTEGER, 'FORBIDDEN'::TEXT, 'Actor user not found or missing role.'::TEXT; RETURN;
    END IF;
    IF NOT (_actor_role_name = ANY(_allowed_roles)) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'FORBIDDEN'::TEXT, 'User does not have permission to create categories.'::TEXT; RETURN;
    END IF;

    _trimmed_name := TRIM(_category_name);
    IF _trimmed_name IS NULL OR _trimmed_name = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'INVALID_INPUT'::TEXT, 'Category name cannot be empty.'::TEXT; RETURN;
    END IF;

    IF EXISTS (SELECT 1 FROM wonks_ru.Categories WHERE lower(name) = lower(_trimmed_name)) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'NAME_EXISTS'::TEXT, 'Category name already exists.'::TEXT; RETURN;
    END IF;

    INSERT INTO wonks_ru.Categories (name)
    VALUES (_trimmed_name)
    RETURNING id INTO _inserted_id;

    IF _inserted_id IS NOT NULL THEN
        RETURN QUERY SELECT _inserted_id, 'OK'::TEXT, 'Category created successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to insert category record.'::TEXT;
    END IF;

EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::INTEGER, 'NAME_EXISTS'::TEXT, 'Category name already exists (concurrent creation).';
    WHEN OTHERS THEN
        RAISE WARNING 'Error creating category by user %: %', _actor_user_id, SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred: ' || SQLERRM::TEXT;
END;
$$;

alter function create_category(integer, varchar) owner to postgres;

grant execute on function create_category(integer, varchar) to "Админ";

grant execute on function create_category(integer, varchar) to "Модератор";

