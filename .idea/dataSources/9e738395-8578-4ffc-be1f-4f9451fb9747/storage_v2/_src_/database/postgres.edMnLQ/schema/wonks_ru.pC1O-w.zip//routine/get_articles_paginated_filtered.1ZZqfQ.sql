create function get_articles_paginated_filtered(_limit integer DEFAULT 10, _offset integer DEFAULT 0, filter_id integer DEFAULT NULL::integer, filter_slug text DEFAULT NULL::text, filter_title text DEFAULT NULL::text, filter_category_name text DEFAULT NULL::text, filter_tags text[] DEFAULT NULL::text[], filter_created_at_start timestamp with time zone DEFAULT NULL::timestamp with time zone, filter_created_at_end timestamp with time zone DEFAULT NULL::timestamp with time zone)
    returns TABLE(id integer, slug text, title text, content text, short_description text, created_at timestamp with time zone, updated_at timestamp with time zone, image text, category_name text, tags text[], rating numeric)
    security definer
    language plpgsql
as
$$
DECLARE
    query         TEXT;
    where_clauses TEXT[] := '{}';
BEGIN
    query := 'SELECT id, slug, title, content, short_description, created_at, updated_at, image, category_name, tags, rating
              FROM wonks_ru.view_articles';

    IF filter_id IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('id = %L', filter_id));
    END IF;

    IF filter_slug IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('slug = %L', filter_slug));
    END IF;

    IF filter_title IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('title ILIKE %L', '%' || filter_title || '%'));
    END IF;

    IF filter_category_name IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('category_name = %L', filter_category_name));
    END IF;

    IF filter_tags IS NOT NULL AND array_length(filter_tags, 1) > 0 THEN
        where_clauses := array_append(where_clauses, format('tags @> %L', filter_tags));
    END IF;

    IF filter_created_at_start IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at >= %L', filter_created_at_start));
    END IF;

    IF filter_created_at_end IS NOT NULL THEN
        where_clauses := array_append(where_clauses, format('created_at <= %L', filter_created_at_end));
    END IF;

    IF array_length(where_clauses, 1) > 0 THEN
        query := query || ' WHERE ' || array_to_string(where_clauses, ' AND ');
    END IF;

    query := query || format(' ORDER BY id DESC LIMIT %L OFFSET %L', _limit, _offset);

    RAISE NOTICE 'Executing query: %', query;

    RETURN QUERY EXECUTE query;
END;
$$;

alter function get_articles_paginated_filtered(integer, integer, integer, text, text, text, text[], timestamp with time zone, timestamp with time zone) owner to postgres;

grant execute on function get_articles_paginated_filtered(integer, integer, integer, text, text, text, text[], timestamp with time zone, timestamp with time zone) to "Админ";

grant execute on function get_articles_paginated_filtered(integer, integer, integer, text, text, text, text[], timestamp with time zone, timestamp with time zone) to "Модератор";

grant execute on function get_articles_paginated_filtered(integer, integer, integer, text, text, text, text[], timestamp with time zone, timestamp with time zone) to "Пользователь";

grant execute on function get_articles_paginated_filtered(integer, integer, integer, text, text, text, text[], timestamp with time zone, timestamp with time zone) to "Гость";

