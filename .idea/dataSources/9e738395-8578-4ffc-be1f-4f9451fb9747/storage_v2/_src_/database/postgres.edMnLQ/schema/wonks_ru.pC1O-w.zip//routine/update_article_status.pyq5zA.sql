create function update_article_status(_article_id integer, _moderator_id integer, _new_status article_status)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _moderator_role_name TEXT;
    _allowed_roles TEXT[] := ARRAY['Administrator', 'Moderator'];
    _row_count INTEGER;
BEGIN
    SELECT r.name INTO _moderator_role_name
    FROM wonks_ru.Users u
             JOIN wonks_ru.Roles r ON u.role_id = r.id
    WHERE u.id = _moderator_id;

    IF NOT FOUND THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'Moderator user not found or missing role.'::TEXT;
        RETURN;
    END IF;

    IF NOT (_moderator_role_name = ANY(_allowed_roles)) THEN
        RETURN QUERY SELECT 'FORBIDDEN'::TEXT, 'User does not have permission to update article status.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Articles WHERE id = _article_id) THEN
        RETURN QUERY SELECT 'ARTICLE_NOT_FOUND'::TEXT, 'Article not found.'::TEXT;
        RETURN;
    END IF;

    UPDATE wonks_ru.Articles
    SET
        status = _new_status,
        updated_at = NOW()
    WHERE id = _article_id;

    GET DIAGNOSTICS _row_count = ROW_COUNT;
    IF _row_count > 0 THEN
        RETURN QUERY SELECT 'OK'::TEXT, format('Article %s status updated to %s successfully.', _article_id, _new_status);
    ELSE
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Failed to update article status, it might have been deleted concurrently.';
    END IF;

EXCEPTION
    WHEN invalid_text_representation THEN
        RAISE WARNING 'Invalid enum value during article status update: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'Invalid status value provided.';
    WHEN OTHERS THEN
        RAISE WARNING 'Error updating article status for article % by user %: %', _article_id, _moderator_id, SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred while updating article status: ' || SQLERRM::TEXT;
END;
$$;

alter function update_article_status(integer, integer, article_status) owner to postgres;

grant execute on function update_article_status(integer, integer, article_status) to "Админ";

grant execute on function update_article_status(integer, integer, article_status) to "Модератор";

