create function subscribe_to_user(_follower_id integer, _followed_id integer, _receive_notices boolean DEFAULT false)
    returns TABLE(status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _follower_exists BOOLEAN;
    _followed_exists BOOLEAN;
BEGIN
    IF _follower_id = _followed_id THEN
        RETURN QUERY SELECT 'SELF_SUBSCRIPTION'::TEXT, 'Cannot subscribe to yourself.'::TEXT; RETURN;
    END IF;
    SELECT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _follower_id) INTO _follower_exists;
    IF NOT _follower_exists THEN
        RETURN QUERY SELECT 'FOLLOWER_NOT_FOUND'::TEXT, 'Follower user not found.'::TEXT; RETURN;
    END IF;
    SELECT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _followed_id) INTO _followed_exists;
    IF NOT _followed_exists THEN
        RETURN QUERY SELECT 'FOLLOWED_NOT_FOUND'::TEXT, 'User to follow not found.'::TEXT; RETURN;
    END IF;

    INSERT INTO wonks_ru.Subscriptions (follower_id, followed_id, notices)
    VALUES (_follower_id, _followed_id, _receive_notices)
    ON CONFLICT (follower_id, followed_id)
        DO NOTHING;

    RETURN QUERY SELECT 'OK'::TEXT, 'Successfully subscribed (or already subscribed).'::TEXT;
EXCEPTION
    WHEN OTHERS THEN
        RAISE WARNING 'Error during subscription: %', SQLERRM;
        RETURN QUERY SELECT 'ERROR'::TEXT, 'An unexpected error occurred during subscription: ' || SQLERRM::TEXT;
END;
$$;

alter function subscribe_to_user(integer, integer, boolean) owner to postgres;

grant execute on function subscribe_to_user(integer, integer, boolean) to "Админ";

grant execute on function subscribe_to_user(integer, integer, boolean) to "Модератор";

grant execute on function subscribe_to_user(integer, integer, boolean) to "Пользователь";

