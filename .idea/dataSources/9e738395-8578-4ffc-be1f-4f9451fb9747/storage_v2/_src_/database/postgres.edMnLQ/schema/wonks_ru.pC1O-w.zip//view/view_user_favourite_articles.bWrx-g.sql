create view view_user_favourite_articles (favourite_id, user_id, username, slug, title, image, short_description) as
SELECT f.id             AS favourite_id,
       u.id             AS user_id,
       u.username::text AS username,
       a.slug,
       a.title::text    AS title,
       a.image::text    AS image,
       a.short_description
FROM favourites f
         JOIN articles a ON f.article_id = a.id
         JOIN users u ON f.user_id = u.id
ORDER BY f.id DESC;

alter table view_user_favourite_articles
    owner to postgres;

