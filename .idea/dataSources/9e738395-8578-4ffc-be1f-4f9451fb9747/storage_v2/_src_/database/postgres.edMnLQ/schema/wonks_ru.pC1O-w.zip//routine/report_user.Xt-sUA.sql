create function report_user(_reporter_id integer, _target_id integer, _content text)
    returns TABLE(new_report_id integer, status_code text, message text)
    security definer
    language plpgsql
as
$$
DECLARE
    _trimmed_content TEXT;
    _inserted_report_id INTEGER := NULL;
    _reporter_status USER_STATUS;
BEGIN
    IF _reporter_id = _target_id THEN
        RETURN QUERY SELECT NULL::INTEGER, 'SELF_REPORT'::TEXT, 'Cannot report yourself.'::TEXT;
        RETURN;
    END IF;

    SELECT status INTO _reporter_status FROM wonks_ru.Users WHERE id = _reporter_id;
    IF NOT FOUND THEN
        RETURN QUERY SELECT NULL::INTEGER, 'REPORTER_NOT_FOUND'::TEXT, 'Reporter user not found.'::TEXT;
        RETURN;
    END IF;

    IF _reporter_status <> 'activated' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'REPORTER_INACTIVE'::TEXT, 'Reporter user account is not active.'::TEXT;
        RETURN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM wonks_ru.Users WHERE id = _target_id) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'TARGET_NOT_FOUND'::TEXT, 'Target user not found.'::TEXT;
        RETURN;
    END IF;

    _trimmed_content := TRIM(_content);
    IF _trimmed_content IS NULL OR _trimmed_content = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'EMPTY_CONTENT'::TEXT, 'Report content cannot be empty.'::TEXT;
        RETURN;
    END IF;

    INSERT INTO wonks_ru.Reports (reporter_id, target_id, content)
    VALUES (_reporter_id, _target_id, _trimmed_content)
    RETURNING id INTO _inserted_report_id;

    IF _inserted_report_id IS NOT NULL THEN
        RETURN QUERY SELECT _inserted_report_id, 'OK'::TEXT, 'Report submitted successfully.'::TEXT;
    ELSE
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed to submit report record.'::TEXT;
    END IF;

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE WARNING 'Foreign key violation during report submission: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'Failed due to invalid reporter_id or target_id.';
    WHEN OTHERS THEN
        RAISE WARNING 'Error submitting report: %', SQLERRM;
        RETURN QUERY SELECT NULL::INTEGER, 'ERROR'::TEXT, 'An unexpected error occurred while submitting the report: ' || SQLERRM::TEXT;
END;
$$;

alter function report_user(integer, integer, text) owner to postgres;

grant execute on function report_user(integer, integer, text) to "Админ";

grant execute on function report_user(integer, integer, text) to "Модератор";

grant execute on function report_user(integer, integer, text) to "Пользователь";

